 
<?php
require_once("includes/load.php");
$all_rooms= find_all('rooms');
$count_rooms = count_by_id('rooms');
$total_rooms = $count_rooms['total'];
$page_title = 'Patient Room Assignments';
 ?>
  <?php
 if(isset($_POST['submit_patient'])){
   $req_field = array('name', 'capacity');
   validate_fields($req_field);
   $name = remove_junk($db->escape($_POST['name']));
    $capacity= remove_junk($db->escape($_POST['capacity']));
		 
   if(empty($errors)){
      $sql  = "INSERT INTO rooms ( name, capacity, room_remaining)";
	  //when creating a new room, capacity the same as the room remaining
      $sql .= " VALUES ('{$name}', '{$capacity}', '{$capacity}')";
	 
      if($db->query($sql)){
		
		 
		  insert_act('room', 'added', '1');
        $session->msg("s", "Successfully added room");
        redirect('rooms.php',false);
		 
		 
		
      } 
	  else {
		  		  insert_act('room', 'added', '0');

        $session->msg("d", "Sorry failed to create room.");
        redirect('rooms.php',false);
      }
   }
   else {
     $session->msg("d", $errors);
     redirect('rooms.php',false);
   }
 }
?>
    <?php
	include('nurse_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
        <?php echo display_msg($msg); ?>

		
		<div class="page-header">
		 <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Nurse</a>
            </li>
            <li class="breadcrumb-item active">Rooms</li>
			<li class="breadcrumb-item active">All Rooms</li>
			<li class="breadcrumb-item">
              <a href="add_room.php">Nurse</a>
            </li>

          </ol>
       <ol class="breadcrumb">      
            <li class="breadcrumb-item active"><b>All Rooms : </b> <?php echo $total_rooms; ?>
		
			</li>
			
          </ol>
		  
		  
		</div>
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-7">
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Capacity</th>
                   <th>Actions</th>
				 
              </thead>
			    <tfoot>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Capacity</th>
                  <th> Actions</th> 
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($all_rooms as $a_room): 
	  ?>

		<tr class='prev' id="pre<?php echo $a_room['id']?>">
      <td><?php echo count_id() ?></td>
       <td><?php echo $a_room ['name']?> </td>
		<td><?php echo $a_room['capacity'] ?></td>
        
		<td>
		<div class='btn btn-info btn-xs edit-button' did='<?php echo $a_room['id']?>'><i class = 'fa fa-info' title = "info, edit & add new"data-toggle = "tooltip" data-placement="bottom"></i></div>
		 


                 <button class = 'btn btn-danger'onclick = "deleteRoom(<?php echo $a_room['id']?>)" class="btn btn-danger"  title="Delete" data-toggle="tooltip">
                  <span class="fa fa-trash"></span></button> 
   
	 </td>
         </tr>
	<?php endforeach; ?>

			  
		
			  
			  </tbody>		
         </table>

          </div>
		
		
		
		<!-- end table of  users --->
          <div class="col-md-5 employeeform" style = "display:none;">
            <p id="message"></p>
            <form method="post" action = "rooms.php">
             <table class="table table-striped">
		
		
		<tr>
             <th> <input type="text" name="name" class="form-control" placeholder="Name " required></th>
			<td><input type="number" name="capacity" class="form-control" placeholder="" required></td>
		</tr>
		
		
		
		<tr>
			<th><button type="submit" name = "submit_patient"class="btn btn-block btn-info insertButton">Submit</button></th>
			
		</tr>
		<tr>
			
		</tr>
			
	</table>
        </form>
       </div>
          <div class="col-md-5 viewemployee" style="display:none;"></div>
		  <div class="col-md-5 edit-room" style="display:none;"></div>

		  
		   
		   
		   </div>


         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   <script> 
      $(document).ready(function(){
       
          //View Employee
        $(document).on('click', '.edit-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "room_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
	
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">
           function deleteRoom(x){
          sweetAlert({   title: "Proceed to delete room?!",
                                text: "room  will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_room.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
										  
  }

 </script>
	

  </body>
  
</html>
