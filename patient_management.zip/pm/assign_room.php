<?php
	include "includes/load.php";
		$id = $_GET['sid'];	
		$patient_info = find_by_id ('patients', $id);
		$all_rooms = find_all ('rooms');
		
		
?>

<?php
//Update User basic info
  if(isset($_POST['assign_room'])) {
    $req_fields = array('room_id', 'patient_id');
    validate_fields($req_fields);
    if(empty($errors)){
         $room_id= (int) $_POST['room_id'];
		 $patient_id = (int) $_POST['patient_id'];
           
			$is_patient_roomless= is_patient_roomless($patient_id)	;
               if ($is_patient_roomless){
			   
				 $sql = "UPDATE medication SET room_number = '{$room_id}' WHERE patient_id = '{$patient_id}'";
				 $result = $db->query($sql);
				  if($result){
				  		    update_room_remaining($room_id);

				   insert_act('patient', ' assigned room', '1');

					$session->msg('s',"admitted patient successfully assigned room ");
					redirect('nurse_patients.php', false);
				  }
				  else {
					insert_act('doctor', 'assigned type', '0');
					$session->msg('d',' Sorry failed to a room to an admitted  patient!');
					redirect('nurse_patients.php', false);
          }
    } 
	
	else 
	{
	   $updateDoctorType = "UPDATE medication SET room_number = {$room_id} WHERE patient_id = '{$patient_id}'";
	    $updateResult = $db->query($updateDoctorType);
          if($updateResult && $db->affected_rows() === 1){
		    update_room_remaining($room_id);
			  			insert_act('patient\'s room', 'changed', '1');

            $session->msg('s',"Admitted Patient\'s Room Changed successfully! ");
            redirect('nurse_patients.php', false);
          } else {
			insert_act('patient\'s room', 'changed', '0');
            $session->msg('d',' Sorry failed to update patient\'s room!');
            redirect('nurse_patients.php', false);
          }
	}
	}
	else {
      $session->msg("d", $errors);
      redirect('nurse_patients.php',false);
    }
  }
?>
 <form method = "post" action = "assign_room.php?sid=<?php echo $patient_info['id']?>">
	<table class="table table-striped">
	

	   <tr style = "background-color:yellowgreen">
	   <th colspan = '3'> Assign Room to Patient</th>
	   </tr>
		<tr>
		
		 <th>Name :</th><td> <?php echo $patient_info['fname']. ' '. $patient_info['sname']; ?></td>
          </tr>
		 <tr>
			<th>Doctor Type</th>
		 <td>   <select class="form-control" name="room">
                  <option value = ""> Select Room</option>
				  <?php foreach ($all_rooms as $a_room):
				  if (is_room_free($a_room['id'])):?>
				  <option value = "<?php echo $a_room['id']?>"> <?php echo $a_room['name']; ?></option>
				  <td> <input type = 'number' value = "<?php echo $a_room['id']?>" name = "room_id" style = "display:none;"> </td>

                </select>
				<?php endif; ?>
				<?php endforeach; ?>
		</tr>
		
			<tr>
			<th> </th>
               <td colspan = "2"> <button class = "btn btn-success" name = "assign_room"> Assign Room</td>
				  <td> <input type = 'number' value = "<?php echo $patient_info['id']?>" name = "patient_id" style = "display:none;"> </td>


            <tr>			
		
	
	</table>
	</form>	
	
	


<?php
// Update user password
if(isset($_POST['update_password'])) {
  $req_fields = array('password');
  validate_fields($req_fields);
  if(empty($errors)){
           $id = (int)$user_info['id'];
     $password = remove_junk($db->escape($_POST['password']));
     $h_pass   = sha1($password);
          $sql = "UPDATE users SET password='{$h_pass}' WHERE id='{$db->escape($id)}'";
       $result = $db->query($sql);
        if($result && $db->affected_rows() === 1){
			insert_act('password', 'changed', '1');
          $session->msg('s',"User password has been updated ");
          redirect('manage_users.php', false);
        } else {
		  insert_act('password', 'changed', '0');
          $session->msg('d',' Sorry failed to updated user password!');
          redirect('manage_users.php', false);
        }
  } else {
    $session->msg("d", $errors);
    redirect('manage_users.php',false);
  }
}
?>

