 
<?php
require_once("includes/load.php");
$all_doc_types = find_all('doctor_types');
$count_doctor_types = count_by_id('doctor_types');
$total_types= $count_doctor_types['total'];
$page_title = 'Doctor Prices';
 ?>
 
    <?php
	include('receptionist_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Reception</a>
            </li>
            <li class="breadcrumb-item active">Manage Default Doctor Charges</li>
          </ol>
		</div>
		
		<div class="page-header">
       <ol class="breadcrumb">
	
            
            <li class="breadcrumb-item active"><b>All Doctor Types: </b> <?php echo $total_types; ?>
		
			</li>
			
          </ol>
		</div>
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-7">
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Doctor Type</th>
                  <th>Price</th>
                   <th>Actions</th>
				 
              </thead>
			    <tfoot>
                <tr>
                  <th>#</th>
                  <th>Doctor Type</th>
				  <th>Price (MK)</th>
                  <th> Actions</th> 
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($all_doc_types as $a_doc_type): 
	  ?>

		<tr class='prev' id="pre<?php echo $a_doc_type['id']?>">
      <td><?php echo count_id() ?></td>
       <td><?php echo $a_doc_type['name']?></td>
		<td><?php echo number_format($a_doc_type['price'], 2) ?></td>
        
		<td>
			 <div class='btn btn-warning edit-button btn-xs' xid ='<?php echo $a_doc_type['id']?>'><i class = 'fa fa-edit'  title = "edit"data-toggle = "tooltip" data-placement="bottom"></i></div>

	 </td>
         </tr>
	<?php endforeach; ?>

			  
		
			  
			  </tbody>		
         </table>

          </div>
		
	
          <div class="col-md-5 viewemployee" style="display:none;"></div>
		   <div class="col-md-5 doc_prices" style="display:none;">
		   <tr>
		  
		
		   
		   </div>


         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   <script> 
      $(document).ready(function(){
       
        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "patient_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
		
		  //View Employee
        $(document).on('click', '.edit-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("xid"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "set_doc_price.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
		
		//assign doc
		 $(document).on('click', '.assign-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
         var eid = $(this).attr("nid"); 
          var Data = {'sid':eid};
          $.ajax({
            url: "assign_doc.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.docPrices', function(){ 
		  $('.doc_prices').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		//end assignment
		
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">
           function deletePatient(x){
          sweetAlert({   title: "Proceed delete patient?!",
                                text: "patient record will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_patient.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
										  
  }

 </script>
  </body>
  
</html>
