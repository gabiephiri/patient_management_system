
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(1);
?>
<?php
  $delete_id = delete_by_id('medicine',(int)$_GET['id']);
  if($delete_id){
	  insert_act('medical drug', 'deleted', '1');
      $session->msg("s","medicine deleted successfully.");
      redirect('manage_medicine.php');
  } else {
	  insert_act('medical drug', 'deleted', '0');
      $session->msg("d","medicine deletion failed Or Missing Prm.");
      redirect('manage_medicine.php');
  }
?>
