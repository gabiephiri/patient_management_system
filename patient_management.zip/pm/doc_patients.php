 
<?php require_once("includes/load.php");
$page_title = "Doctor Patients";
$from_reception = find_patients_by_status ('rec');
$from_lab = find_patients_by_status ('labdoctor');
$totalRecPatients = count_by_patient_status('rec');
$totalLabPatients = count_by_patient_status('lab');

$recPatientCount = $totalRecPatients['total'];
$labPatientCount = $totalLabPatients['total'];

$totalDocPatients = (int)($labPatientCount + $recPatientCount);


 ?>
  <?php
 if(isset($_POST['submit_patient'])){
   $req_field = array('first_name', 'last_name', 'sex', 'birth_year');
   validate_fields($req_field);
   $first_name = remove_junk($db->escape($_POST['first_name']));
   $last_name = remove_junk($db->escape($_POST['last_name']));
   $email_address = remove_junk($db->escape($_POST['email_address']));
   $phone_number = remove_junk($db->escape($_POST['phone_number']));
   $sex = remove_junk($db->escape($_POST['sex']));
      $blood_group = remove_junk($db->escape($_POST['blood_group']));
	     $birth_year = remove_junk($db->escape($_POST['birth_year']));
		 
   if(empty($errors)){
      $sql  = "INSERT INTO patients ( fname, sname,  email, phone, sex, bloodgroup, birthyear)";
      $sql .= " VALUES ('{$first_name}', '{$last_name}','{$email_address}','{$phone_number}', '{$sex}', '{$blood_group}', '{$birth_year}')";
      if($db->query($sql)){
		  insert_act('patient', 'added', '1');
        $session->msg("s", "Successfully added patient");
        redirect('manage_patients.php',false);
      } else {
		  		  insert_act('patient', 'added', '0');

        $session->msg("d", "Sorry failed to create user.");
        redirect('manage_patients.php',false);
      }
   } else {
     $session->msg("d", $errors);
     redirect('manage_patients.php',false);
   }
 }
?>
    <?php
	include('doctor_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Doctor</a>
            </li>
            <li class="breadcrumb-item active">Patients</li>
			<li class="breadcrumb-item active">From Reception &amp; Laboratory</li>
          </ol>
		</div>
		
		<div class="page-header">
       <ol class="breadcrumb">
	   
	   <?php 
	   
	   
	
	   ?>
            
            <li class="breadcrumb-item active"><b>All Patients : </b> <?php echo $totalDocPatients; ?>
		
			</li>
			
          </ol>
		</div>
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-7">
		 	<h3>FROM THE LABORATORY</h3>
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Sex</th>
				   <th>Added</th>
                   <th>Actions</th>
				 
              </thead>
			    <tfoot>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Sex</th>
				  <th>Added</th>
                  <th> Actions</th> 
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($from_lab  as $r_patient): 
	  ?>

		<tr class='prev' id="pre<?php echo $r_patient['id']?>">
      <td><?php echo count_id() ?></td>
       <td><?php echo $r_patient['fname']. ' '. $r_patient['sname'];?> </td>
		<td><?php echo $r_patient['sex'] ?></td>
        <td><?php echo read_date($r_patient['dateadded']);?></td>
        
		<td>
		<div class='btn btn-info btn-xs view-button' did='<?php echo $r_patient['id']?>'><i class = 'fa fa-info' title = "info & create new"data-toggle = "tooltip" data-placement="bottom"></i></div>
		    <div class='btn btn-warning btn-xs'><a href = "add_med_lab.php?id=<?php echo $r_patient['id']?>" title = "add medicine for pharmacist"data-toggle = "tooltip" data-placement="bottom"><i class = 'fa fa-first-aid'></i></a>
   
                
   
	 </td>
         </tr>
	<?php endforeach; ?>		
		
			  
			  </tbody>		
         </table>
		 
		<h3>FROM THE RECEPTION</h3>
		 
		  <table class="table table-striped" id = "dataTable2" cellspacing = "0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Sex</th>
				   <th>Added</th>
                   <th>Actions</th>
				 
              </thead>
			    <tfoot>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Sex</th>
				  <th>Added</th>
                  <th> Actions</th> 
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($from_reception  as $l_patient): 
	  ?>

		<tr class='prev' id="pre<?php echo $l_patient['id']?>">
      <td><?php echo count_id() ?></td>
       <td><?php echo $l_patient['fname']. ' '. $l_patient['sname'];?> </td>
		<td><?php echo $l_patient['sex'] ?></td>
        <td><?php echo read_date($l_patient['dateadded']);?></td>
        
		<td>
		<div class='btn btn-info btn-xs view-button' did='<?php echo $l_patient['id']?>'><i class = 'fa fa-info' title = "info & create new"data-toggle = "tooltip" data-placement="bottom"></i></div>
		  <div class='btn btn-info btn-xs edit-button'><a style = "text-decoration:none;"href = "add_sym_rec.php?id=<?php echo $l_patient['id']?>" title = "add symptons and test suggestions for lab personnel"data-toggle = "tooltip" data-placement="bottom"><i class = 'fa fa-user'></i></a>
   
	 </td>
         </tr>
	<?php endforeach; ?>

			  
		
			  
			  </tbody>		
         </table>


          </div>
		
		
		
		<!-- end table of  users --->
          <div class="col-md-5 employeeform" style = "display:none;">
            <p id="message"></p>
            <form method="post" id="insert">
             <table class="table table-striped">
		
		
		<tr>
             <th> <input type="text" name="first_name" class="form-control" placeholder="First  Name " required></th>
			<td><input type="text" name="last_name" class="form-control" placeholder="Last Name " required></td>
		</tr>
		<tr>
		    <th> <input type="email_address" name="email_address" class="form-control" placeholder="Email Address" ></th>
			<td><input type="phone" name="phone_number" class="form-control" placeholder="Phone Number"></td>
		</tr>
		
		<tr>

			<td>
			
			 <select class="form-control" name="sex" required = "required">
				<option value = "">Select Gender</option> 
                   <option value="Female">Female</option>
				   <option value="Male">Male</option>
                </select>
			
			</td>
			
			<td>
			
			 <select class="form-control" name="blood_group" required = "required">
				<option value = "">Blood Group</option> 
                   <option value="A">A</option>
				   <option value="B">B</option>
				   <option value="AB">AB</option>
				   <option value="O">O</option>
                </select>
			
			</td>
			
		</tr>
		<tr>
		<th> Year of Birth </th>
		<td>
			
			 <select class="form-control" name="birth_year" required = "required" >
				<option value = "">Select </option> 
				
				<?php 
				
				$thisYear = date ('Y');
				$numberYear = (int) $thisYear;
				
				for($birthyear = 1920; $birthyear <= $thisYear; $birthyear++) :?>
                   <option value="<?php echo (int)$birthyear ?>"><?php echo $birthyear ?></option>
				   <?php endfor; ?>
                </select>
			
			</td>
		
		</tr>
		<tr>
			<th><button type="submit" name = "submit_patient"class="btn btn-block btn-info insertButton">Submit</button></th>
			
		</tr>
		<tr>
			
		</tr>
			
	</table>
            </form>
       </div>
          <div class="col-md-5 viewemployee" style="display:none;"></div>

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
     <script> 
      $(document).ready(function(){


        //View Employee
        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "doc_rec_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
		
		 
		  //View Employee
        $(document).on('click', '.edit-button-lab', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var jid = $(this).attr("lid"); 
          var Data = {'bid':jid};
          $.ajax({
            url: "add_med_lab.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		

		 function deleteUser(x){
           sweetAlert({   title: "Proceed to delete user?!",
                                text: "user account will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_user.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } 
										  
					});
		
		 

		 }
		
		
	
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">
           function deletePatient(x){
          sweetAlert({   title: "Proceed delete patient?!",
                                text: "patient record will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_patient.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
										  
  }

 </script>
  </body>
  
</html>
