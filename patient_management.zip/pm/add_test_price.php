<?php
	require_once "includes/load.php";
        $id = $_GET['id'];	
         $patient_info = find_by_id('patients', $id);
        $user = current_user();
        $docId = $user['id'];		
		?>
<?php
      if(isset($_POST['submit_test_price'])) {
		  
		   $req_field = array('test_price', 'test_results');
           validate_fields($req_field);
		  
 		     $patient_id = $_POST['patient_id'];
			 
		   $test_results = remove_junk ($db->escape($_POST['test_results']));
			 

		   $test_price = remove_junk ($db->escape($_POST['test_price']));
		   

			 if(empty($errors)){		  

                  $sql = "UPDATE medication SET status = 'labdoctor', test_price= '{$test_price}', test_results = '{$test_results}', doctor = '{$docId}' WHERE patient_id = {$patient_id}";
			
			
          $result = $db->query($sql);
          if($result)
		  {
			insert_act('test cost', 'charged', '1');

            $session->msg('s',"test cost set successfully ");
            redirect('lab_patients.php?eid='.$patient_id, false);
          } else {
			insert_act('test cost', 'charged', '0');
            $session->msg('d',' Sorry failed to charge the the test!');
            redirect('lab_patients.php?eid='.$patient_id, false);
          }
     } 
	 else 
	 {
		 $session->msg ("d", $errors);
		 $redirect ("lab_patients_patients.php", false);
	 }
	  }
?>
    <?php
	include('laboratory_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Laboratory</a>
            </li>
            <li class="breadcrumb-item active">Manage Tests</li>
			<li class="breadcrumb-item active">Test Results &amp; Costs</li>
          </ol>
		</div>
		
		
        <div class="row">
		<!-- start with table of users -->
	<!-- end table of  users --->
          <div class="col-md-6 employeeform">
            <p id="message"></p>

 <form method = "post" action = "add_test_price.php">
	<table class="table table-striped">
	

	<tr colspan = '2' >
	
	
	<td>
	<textarea name = "test_results" type = "test" class = "form-control" placeholder = "Add Test Results" value = ""></textarea>
	</td>		
   </tr>
   <tr>
   		<th><input name = "test_price" type = "text"  onfocus = "this.type='number'" placeholder = "test price"class = "form-control" value = ""></td>

   </tr>
   <tr>
    
 <th><button class = "btn btn-success" type = "submit" name = "submit_test_price">Submit Test Results &amp; Price</th>
 </tr>
 <tr style = 'display:none'>
 <th><input  class = "form-control" type = "number" name = "patient_id" value = "<?php echo $patient_info['id']?>"></th>

   
   
   </tr>

		
		<!--end of main form -->
		
		
	</table>
	</form>
	
	
	
	


