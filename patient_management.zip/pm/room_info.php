<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	$room_info = find_by_id ('rooms', $id);
	
	if (!$room_info)
	{
	   $session->msg('d', "Missing room id");
	   redirect('rooms.php', false);
	}
?>
<?php
if (isset($_POST['submit_changes']))
{
$reqfields = array('name', 'capacity');
validate_fields (reqfields);
if (empty($errors))
{
      $name = remove_junk ($db->escape($_POST['name']));
      $capacity = remove_junk ($db->escape($_POST['capacity']));
	  $room_id = remove_junk ($db->escape($_POST['room_id']));
	  
	  $updateQuery = "UPDATE rooms SET name = '{$name}', capacity = '{$capacity}' WHERE id = '{$room_id}'";
	  $result = $db->query($updateQuery);
	  
	  if ($result)
	  {
	     $session->msg('s', "Room updated successfully");
		 redirect ('rooms.php', false);
	  }
	  else 
	  { 
         $session->msg('s', "sorry updating room failed");
		 redirect ('rooms.php', false);
	  }

 
}
else{
  $session->msg('d', $errors);
  redirect ('rooms.php', false);
}
}


?>

<form action = "room_info.php?eid=<?php echo $room_info['id']?>" method = "post">
	<table class="table table-striped">
		
		
		<tr>
			<th>Name</th>
			<td> <input type = "text" name = "name" value = "<?php echo $room_info['name'] ?>"> </td>
		</tr>
		<tr>
			<th>Capacity</th>
			<td> <input type = "number" name = "capacity" value = "<?php echo $room_info['capacity'] ?>"> </td>
			<td> <input type = "number" style = "display:none;"name = "room_id" value = "<?php echo $room_info['id'] ?>"> </td>

		</tr>
<tr>
            <th><button class="btn btn-warning" name = "submit_changes">Submit Changes</button></th>

<tr>		
	</table>

</form>


