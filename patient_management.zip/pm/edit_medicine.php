<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	$medicine_info = find_by_id ('medicine', $id);
?>

<?php
//Update User basic info
  if(isset($_POST['update_medicine'])) {
    $req_fields = array('name', 'price', 'least_amount', 'amount', 'expiry_date');
    validate_fields($req_fields);
    if(empty($errors)){
         $medicine_id = (int) $_POST['medicine_id'];
           
		   $name = remove_junk($db->escape($_POST['name']));
		   $price = remove_junk($db->escape($_POST['price']));
		   $amount = remove_junk($db->escape($_POST['amount']));
		   $least_amount = remove_junk($db->escape($_POST['least_amount']));
		   $expiry_date = remove_junk($db->escape($_POST['expiry_date']));
		   $last_touched = make_date();



					  

         $sql = "UPDATE medicine SET name ='{$name}', price ='{$price}', amount = '{$amount}', least_amount = '{$least_amount}', last_touched ='{$last_touched}', expiry_date = '{$expiry_date}' WHERE id='{$medicine_id}'";
			
			
         $result = $db->query($sql);
          if($result){
		insert_act('medicine', 'updated', '1');

            $session->msg('s',"medicine updated ");
            redirect('manage_medicine.php', false);
          } else {
			insert_act('medicine', 'updated', '0');
            $session->msg('d',' Sorry failed to update medicine!');
            redirect('manage_medicine.php', false);
          }
    } 
	else {
      $session->msg("d", $errors);
      redirect('manage_medicine.php',false);
    }
  }
  
?>
<form method= "post" action = "edit_medicine.php">
	<table class="table table-striped">
		<tr class = "pull-right">

		</tr>
		
		<tr>
			<th>Name</th>
			<td> <input type = "text" name = "name" class = "form-control"value = "<?php echo $medicine_info['name'] ?>"></td>
		</tr>
		<tr>
			<th>Medicine Price</th>
			<td> <input type = "number" name = "price" class = "form-control"value = "<?php echo $medicine_info['price'] ?>"></td>
		</tr>
		<tr>
			<th>Amount</th>
			<td> <input type = "number" name = "amount" class = "form-control"value = "<?php echo $medicine_info['amount'] ?>"></td>
		</tr>
		<tr>
			<th>Critical Amount <br> (Notify Amount)</th>
			<td> <input type = "number" name = "least_amount" class = "form-control"value = "<?php echo $medicine_info['least_amount'] ?>"></td>
		</tr>
		<tr>
			<th>Expiry Date</th>
			<td> <input type = "text" onfocus = "this.type='date'"placeholder = "<?php echo read_date($medicine_info['expiry_date']) ?>"name = "expiry_date" class = "form-control" ></td>
		</tr>
          <tr>
		              <th><button class="btn btn-primary" name = "update_medicine">Submit Changes</button></th>
		  </tr>
		  <tr>
		 <td> <input type = "number" name = "medicine_id"  class = "form-control"value = "<?php echo $medicine_info['id'] ?>"></td>

		  
		  </tr>
	</table>


