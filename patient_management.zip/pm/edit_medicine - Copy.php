<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	$medicine_info = find_by_id ('medicine', $id);
?>

<?php
//Update User basic info
  if(isset($_POST['update_medicine'])) {
    $req_fields = array('medicine_name', 'medicine_price');
    validate_fields($req_fields);
    if(empty($errors)){
         $medicine_id = (int) $_POST['medicine_id'];
           
		   $medicine_name = remove_junk($db->escape($_POST['medicine_name']));
		   $medicine_price = remove_junk($db->escape($_POST['medicine_price']));
					  

         $sql = "UPDATE medicine SET medicine_name ='{$medicine_name}', price ='{$medicine_price}' WHERE id='{$medicine_id}'";
			
			
         $result = $db->query($sql);
          if($result){
		insert_act('medicine', 'updated', '1');

            $session->msg('s',"medicine updated ");
            redirect('manage_medicine.php', false);
          } else {
			insert_act('medicine', 'updated', '0');
            $session->msg('d',' Sorry failed to update medicine!');
            redirect('manage_medicine.php', false);
          }
    } 
	else {
      $session->msg("d", $errors);
      redirect('manage_medicine.php',false);
    }
  }
  
?>
<form method= "post" action = "edit_medicine.php">
	<table class="table table-striped">
		<tr class = "pull-right">

		</tr>
		
		<tr>
			<th>Name</th>
			<td> <input type = "text" name = "medicine_name" class = "form-control"value = "<?php echo $medicine_info['medicine_name'] ?>"></td>
		</tr>
		<tr>
			<th>Medicine Price</th>
			<td> <input type = "number" name = "medicine_price" class = "form-control"value = "<?php echo $medicine_info['price'] ?>"></td>
		</tr>
          <tr>
		              <th><button class="btn btn-primary" name = "update_medicine">Add Medicine</button></th>
		  </tr>
		  <tr>
		 <td> <input type = "number" name = "medicine_id"  class = "form-control"value = "<?php echo $medicine_info['id'] ?>"></td>

		  
		  </tr>
	</table>


