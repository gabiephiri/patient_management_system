<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	$patient_info = find_by_id ('patients', $id);
	$medication_info = find_med_by_patient_id($id);
	$doctor = $medication_info['doctor'];
	$doctor_info = find_by_id('users', $doctor);
	$doc_name = $doctor_info['first_name'].' '.$doctor_info['last_name'];
	$doc_info = find_doc ($doctor);
	$type = $doc_info['type'];
	$type_name_info = find_by_id('doctor_types', $type);
	$type_name = $type_name_info ['name'];
	
	
?>
	<table class="table table-striped">
		<tr class = "pull-right">
            <th><button class="btn btn-primary addEmployee">Add Patient</button></th>
            <td></td>
		</tr>
		
		<tr>
			<th>Name</th>
			<td> <?php echo $patient_info['fname'] ?> <?php echo $patient_info['sname'] ?></td>
		</tr>
		<tr>
			<th>Assigned to Dr</th>
			<td> <?php echo $doc_name ?> of Type <?php echo $type_name ?></td>
		</tr>
		

		<?php if (!is_null($patient_info['email'])) :?>
		<tr>
			<th><i class = "fa fa-envelope">  Email</th>
			<td>
			
			<?php echo  $patient_info['email']; ?>
			</td>
		</tr>
		<?php endif; ?>
		<?php if (!is_null($patient_info['phone'])):?></td>
		<tr>
		<th><i class = "fa fa-phone"> </i>  Phone</th>
		<td>
              <?php echo $patient_info['phone']; ?>
		</td>
		</tr>
		
		<?php endif; ?>
		
		<tr>
		
			<th>Blood Group</th>
			<td><?php echo strtoupper($patient_info['bloodgroup']);?></td>
		</tr>
		<tr>
			<th>Birth Year</th>
			<td> <?php echo $patient_info['birthyear'] ?> &nbsp; &nbsp;  <b>  Age : </b> <?php echo (int) date('Y') - $patient_info['birthyear']; ?> </td>
		</tr>
		<tr>
			<th><i class = "fa fa-calendar"> </i>  Date of Recording</th>
			<td> <?php echo read_date ($patient_info['dateadded'])?>  </td>
		</tr>
		
	</table>


