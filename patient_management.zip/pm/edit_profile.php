<?php
require_once "includes/load.php";
$page_title = "Edit Your Profile";
		$id = $_GET['eid'];	
		$user_info = find_by_id('users', $id);	
		$user_id = $user_info['id'];
		$all_user_groups = find_all('user_groups');	
		
?>

<?php
//Update User basic info
  if(isset($_POST['update_user'])) {
    $req_fields = array('first_name','last_name','username', 'phone_number', 'email_address');
    validate_fields($req_fields);
    if(empty($errors)){
         $user_id = (int) $_POST['user_id'];
		    $title = remove_junk($db->escape($_POST['title']));
           $first_name = remove_junk($db->escape($_POST['first_name']));
		   $last_name = remove_junk($db->escape($_POST['last_name']));
		   $other_names = remove_junk($db->escape($_POST['other_names']));
           $username = remove_junk($db->escape($_POST['username']));
		   $email_address = remove_junk($db->escape($_POST['email_address']));
		   $phone_number = remove_junk($db->escape($_POST['phone_number']));

					  

         $sql = "UPDATE users SET title = '{$title}', first_name ='{$first_name}', last_name ='{$last_name}',other_names='{$other_names}', username = '{$username}',  email_address = '{$email_address}', phone_number = '{$phone_number}' WHERE id='{$user_id}'";
         $result = $db->query($sql);
          if($result && $db->affected_rows() === 1){
			  			insert_act('account', 'updated', '1');

            $session->msg('s',"Acount Updated ");
            redirect('edit_profile.php?eid='.$user_info['id'], false);
          } else {
			insert_act('account', 'updated', '0');
            $session->msg('d',' Sorry failed to updated!');
            redirect('edit_profile.php?eid='.$user_info['id'], false);
          }
    } else {
      $session->msg("d", $errors);
      redirect('edit_profile.php?eid='.$user_info['id'],false);
    }
  }
?>
<?php 
$user = current_user();
$user_level = $user['user_level'];
if ($user_level ==='1')
{
	include_once('admin_header.php');
}
else if ($user_level ==='2')
{
	include('doctor_header.php');
}
else if ($user_level === '3')
{
	include ('bursar_header.php');
}
else if ($user_level === '4')
{
	 include ('pharmacy_header.php');
}
else if ($user_level === '5')
{
	include ('laboratory_header.php');
}

else if  ($user_level === '6'){
	include ('receptionist_header.php');
}
?>


 <div class = "container">
 <?php echo display_msg($msg) ?>
 <div class = "col-md-8">
  <form method = "post" action = "edit_profile.php?eid=<?php echo $user_info['id']?>">
	<table class="table table-striped">
	  <tr><th colspan = "2">Edit Your Account : <?php echo $user_info['first_name'].' '. $user_info ['last_name']; ?></th> </tr>
		<tr>
		 <th>Title </th>
		 <td><select class="form-control" name="title">
				 <option <?php if($user_info['title'] === 'Mr') echo 'selected="selected"';?>value="Mr">Mr</option>
                  <option <?php if($user_info['title'] === 'Mrs') echo 'selected="selected"';?> value="Mrs">Mrs</option>
				  <option <?php if($user_info['title'] === 'Ms') echo 'selected="selected"';?> value="Ms">Ms</option>
				  <option <?php if($user_info['title'] === 'Dr') echo 'selected="selected"';?> value="Dr">Dr</option>
				   <option <?php if($user_info['title'] === 'Prof') echo 'selected="selected"';?> value="Prof">Prof</option>
                </select>
			</td>
		 </tr>
		
		<tr>
			<th>First Name</th>
		 <td> <input name = "first_name" type = "text" class = "form-control" value = "<?php echo $user_info['first_name'] ?>"></td>
		</tr>
		<tr>
	   <th>Last Name </th>
		 <td> <input name = "last_name" type = "text" class = "form-control" value = "<?php echo $user_info['last_name'] ?>"></td>
		 </tr>
		 
		 <tr>
		 <th>Other Names </th>
		 <td> <input name = "other_names" type = "text" class = "form-control" value = "<?php echo $user_info['other_names'] ?>"></td>
		 </tr>
		  <tr>
		 <th>Username </th>
		 <td> <input name = "username" type = "text" class = "form-control" value = "<?php echo $user_info['username'] ?>"></td>
		 </tr>
		  <th>Email Address </th>
		 <td> <input name = "email_address" type = "text" class = "form-control" value = "<?php echo $user_info['email_address'] ?>"></td>
		 </tr>
		  <th>Phone Number </th>
		 <td> <input name = "phone_number" type = "text" class = "form-control" value = "<?php echo $user_info['phone_number']; ?>"></td>
		 </tr>
		 <tr>
         <td><button class = "btn btn-success" type = "submit" name = "update_user">Update</td>
	        <td><input name = "user_id" type = "number" class = "form-control" style = "visibility:hidden;"value = "<?php echo $user_info['id']; ?>"></td>
		</tr>
		<tr>
		
		
	
	</table>
	</form>	
	<form method = "post" action = "edit_profile.php?eid=<?php echo $user_info['id']?>">
	<table class = "table table-striped">
	Change Password
	<tr>
	
		 <td> <input name = "password" type = "text" onfocus = "this.type='password'"class = "form-control" placeholder = "Type new password"value = ""></td>
		 <td><td><button class = "btn btn-danger" type = "submit" name = "update_password">Update Password</td>
 </td>
 <tr style = "display:none;">
 	        <td><input name = "user_id2" type = "number" class = "form-control" value = "<?php echo $user_info['id']; ?>"></td>

 </tr>
		 </tr>
	<tr>
	
	</table>
	</form>
	
	


<?php
// Update user password
if(isset($_POST['update_password'])) {
  $req_fields = array('password');
  validate_fields($req_fields);
  if(empty($errors)){
           $id = (int)$user_info['id'];
     $password = remove_junk($db->escape($_POST['password']));
	      $id = remove_junk($db->escape($_POST['user_id2']));

     $h_pass   = sha1($password);
          $sql = "UPDATE users SET password='{$h_pass}' WHERE id='{$db->escape($id)}'";
       $result = $db->query($sql);
        if($result && $db->affected_rows() === 1){
			insert_act('password', 'changed', '1');
          $session->msg('s',"User password has been updated ");
		  
          echo "<script> alert ('Password Successfully updated'); </script>";
        } else {
		  insert_act('password', 'changed', '0');
          $session->msg('d',' Sorry failed to updated user password!');
          echo "<script> alert ('Password not updated'); </script>";
        }
  } else {
    $session->msg("d", $errors);
          echo "<script> alert ('Something went wrong'); </script>";
  }
}
?>

