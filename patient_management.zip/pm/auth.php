<?php include_once('includes/load.php'); ?>
<?php
$req_fields = array('username','password' );
validate_fields($req_fields);
$username = remove_junk($_POST['username']);
$password = remove_junk($_POST['password']);

if(empty($errors)){
  $user_id = authenticate($username, $password);
  if($user_id){
    //create session with id
     $session->login($user_id);
    //Update Sign in time
     updateLastLogIn($user_id);
	 
	 $user = current_user();
	 if ($user['user_level'] === '1'){
     $session->msg("s", "  Welcome Admin " . $user ['username']);
     redirect('manage_users.php',false);
	 }
	 
	  else if ($user['user_level'] === '2'){
     $session->msg("s", "  Welcome Doctor " . $user ['username']);
     redirect('doc_patients.php',false);
	 }
	  else if ($user['user_level'] === '3'){
     $session->msg("s", "  Welcome Finance Officer " . $user ['username']);
     redirect('bursar_reports.php',false);
	 }
	  else if ($user['user_level'] === '4'){
     $session->msg("s", "  Welcome Pharmacist " . $user ['username']);
     redirect('pharm_patients.php',false);
	 }
	  else if ($user['user_level'] === '5'){
     $session->msg("s", "  Welcome Laboratorist " . $user ['username']);
     redirect('lab_patients.php',false);
	 }
	  else if ($user['user_level'] === '6'){
     $session->msg("s", "  Welcome Receptionist " . $user ['username']);
     redirect('manage_patients.php',false);
	 }
	 
	 else if ($user['user_level'] === '7'){
     $session->msg("s", "  Welcome Nurse " . $user ['username']);
     redirect('nurse_patients.php',false);
	 }

  } else {
    $session->msg("d", "Sorry Username/Password incorrect.");
    redirect('index.php',false);
  }

} else {
   $session->msg("d", $errors);
   redirect('index.php',false);
}

?>
