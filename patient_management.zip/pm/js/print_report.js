
function printElem(elem)
{
	var myWindow = window.open('', 'PRINT', 'height = 600, width=500');
	myWindow.document.write('<html><head><title>'+ document.title + '</title>');
	myWindow.document.write('</head><body>');
	myWindow.document.write(document.getElementById(elem).innerHTML);
	myWindow.document.write('<button class = \'btn btn-success fa fa-print pull-right\'onclick = \'window.print()\'>Print</button>');
	myWindow.document.write('</body></html>');
	myWindow.document.close();
	myWindow.focus();
	return true;
	
}
