<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	$medicine_info = find_by_id ('medicine', $id);
?>
	<table class="table table-striped">
		<tr class = "pull-right">
            <th><button class="btn btn-primary addEmployee">Add Medicine</button></th>
            <td></td>
		</tr>
		
		<tr>
			<th>Name</th>
			<td> <?php echo $medicine_info['name'] ?> </td>
		</tr>
		<tr>
			<th>Medicine Price</th>
			<td> <?php echo $medicine_info['price'] ?> </td>
		</tr>
		
		<tr>
			<th>Amount Remaining</th>
			<?php if (is_drug_enough($medicine_info['id'])):?>
			<td style = "background-color:green!important; color:white !important"> <?php echo $medicine_info['amount'] ?> </td>
			<?php else: ?>
			<td style = "background-color:red!important; color:white !important"> <?php echo $medicine_info['amount'] ?> </td>
			<?php endif; ?>

		</tr>
		<tr>
			<th>Least Amount</th>
			<td> <?php echo $medicine_info['least_amount'] ?> </td>
		</tr>
		<tr>
			<th>Expiry Date</th>
			<td> <?php echo read_date($medicine_info['expiry_date']) ?> </td>
		</tr>
		<tr>
			<th>Last Modified</th>
			<td> <?php echo read_date($medicine_info['last_touched']) ?> </td>
		</tr>
		
		<tr>
			<th>Days To Expiry</th>
			<?php
			   $days_to_expiry = count_days_to_expiry($medicine_info['id']);

			if (!is_drug_fresh($medicine_info['id'])): ?>
			
				<td style = "background-color:white; color: red !important; !font-weight:bolder !important">	
				<?php echo "Expired ".$days_to_expiry. " days ago"; ?>
					 </td>
									
			<?php else: ?>
					
					<td style = "background-color:green !important; color:white !important; font-weight:bolder !important;"> <b><?php echo "Expiring in ".$days_to_expiry. " days "; ?>
</b></td>
					
					
			<?php endif; ?>
			
		</tr>

	
		
		
	</table>


