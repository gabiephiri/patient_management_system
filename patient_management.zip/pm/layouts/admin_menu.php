     <link rel="stylesheet" href="libs/css/bootstrap.css" />
	 <link rel="stylesheet" href="libs/css/bootstrap.min.css" />
<ul>
  <li>
    <a href="admin.php">
      <i class="fa fa-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
    <a href="users.php">
      <i class="fa fa-user"></i>
      <span>Users</span>
    </a>
  </li>
<li>
    <a href="products.php">
      <i class="fa fa-shopping-bag"></i>
      <span>Products</span>
    </a>
 </li>
  <li>
    <a href="subservices.php" class="submenu-toggle">
      <i class="fa fa-wrench"></i>
       <span>Services</span>
  </li>
  
  <li>
    <a href="company_info.php" class="submenu-toggle">
      <i class="fa fa-info"></i>
       <span>About Us</span>
     
  </li>
   <li>
    <a href="sales.php" class="submenu-toggle">
      <i class="fa fa-gbp"></i>
       <span>Sales</span>
     
  </li>
  <li>
    <a href="quotations.php" class="submenu-toggle">
      <i class="fa fa-paperclip"></i>
       <span>Quotations</span>
     
  </li> 
  <li>
    <a href="acts_log.php" >
      <i class="fa fa-tasks"></i>
      <span>Activity Log</span>
    </a>
  </li>
</ul>

