     </div>
    </div>
    <script src="libs/js/jquery-1.9.0.min.js"></script>
  <script src="libs/js/bootstrap.min.js"></script>
  <script src="libs/js/bootstrap-datepicker.min.js"></script>
  <script type="text/javascript" src="libs/js/functions.js"></script>
  </body>
</html>

<?php if(isset($db)) { $db->db_disconnect(); } ?>
