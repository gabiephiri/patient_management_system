<?php $user = current_user(); 
$messages = count_by_id('messages');
$acts= count_by_id('acts_log');


?>
<!DOCTYPE html>
  <html lang="en">
    <head>
    <meta charset="UTF-8">
    <title><?php if (!empty($page_title))
           echo remove_junk($page_title);
            elseif(!empty($user))
           echo ucfirst($user['name']);
		   
            else echo "Sigma Admin";?>
    </title>
  

    <link  rel= "stylesheet" href = "datepicker/jquery-ui.css" />
	
	<link rel = "stylesheet" href = "../fontsome/css/font-awesome.css"/>
			    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
				    <link rel="stylesheet" href="../libs/css/bootstrap.css" />
	 <link rel="stylesheet" href="../libs/css/bootstrap.min.css" />
	 
	 		<link href="css2/sb-admin.css" rel="stylesheet">


   <link rel="stylesheet" href="libs/css/main.css" /> 
	<link rel="stylesheet" href="font-awesome.css" /> 

	
	    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

   <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel = "shortcut icon" type="img/png" href="../images/sigma_logo_small.png">	
	<link type="text/css" rel="stylesheet" href="bootstrap-3.1.1-dist/css/bootstrap.css" />
			<link type="text/css" rel="stylesheet" href="libs/css/font-awesome.css" />
		<link type="text/css" rel="stylesheet" href="font-awesome-4.6.1/css/font-awesome.css" />
		<link type="text/css" rel="stylesheet" href="css/custom.css" />
		<script src="sweetalert-master/dist/sweetalert.min.js"></script> 
		<link rel="stylesheet" href="datatables/dataTables.bootstrap.css">
		<link rel="stylesheet" href="css/jquery-ui.css">
		<link rel="stylesheet" href="datepicker/datepicker3.css">
			 <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->

    <!-- Demo scripts for this page-->
    <script src="js2/demo/datatables-demo.js"></script>
    <script src="js2/demo/chart-area-demo.js"></script>

		<link rel="stylesheet" href="datepicker/jquery.timepicker.css">
		<link rel="stylesheet" type="text/css" href="sweetalert-master/dist/sweetalert.css">
		<script src="assets/js/jquery-1.10.2.min.js"></script>		
	<script src="js/bootstrap.min.js"></script>
	<script src="assets/js/custom.js"></script>
		<script type='text/javascript' src='js/jquery.js'></script>
		<script type="text/javascript" src="js/highcharts.js" ></script>
		<script type="text/javascript" src="js/themes/dark-blue.js"></script>
		<script type='text/javascript' src='js/sortTable.js'></script>
		<script type='text/javascript' src='timepicker/jquery.timepicker.min.js'></script>
		<script type='text/javascript' src='timepicker/jquery.timepicker.js'></script>
		<script type='text/javascript' src='js/bootstrap.js'></script>
		<script type='text/javascript' src='js/jquery-ui.js'></script>
		<script src="datatables/jquery.dataTables.min.js"></script>
		<script src="datatables/dataTables.bootstrap.min.js"></script>
		<script src="datapicker/datapicker.js"></script>
		<script src="js2/sb-admin.js"></script>

  </head>
  <body>
  <?php  if ($session->isUserLoggedIn(true)): ?>
    <header id="header" style = "background-color:#C1BC09">
      <div class="logo pull-left" style = "background-color:black; margin-left:-2%;"><span><img class = "img-circle" src = '../images/sigma_logo_small.png' height = "48px" width = "48px"></img></span> Sigma Admin</div>
      <div class="header-content">
 <div class="header-date pull-left" >
      <strong>
		<!--start add menu -->

		
		<!--end add menu -->
		</strong>
      </div>
	  <!--start here --->
	  

	  <!-- end final -->
      <div class="pull-right clearfix">
        <ul class="info-menu list-inline list-unstyled">
          <li class="profile" >
            <a href="#" data-toggle="dropdown" class="toggle" aria-expanded="false">
                <img class="img-circle img-size-2" src="../images/users/<?php echo $user['image'];?>" alt="">
              <span><?php echo remove_junk(ucfirst($user['name'])); ?> <i class="caret"></i></span>
            </a>
            <ul class="dropdown-menu">
              <li>
                  <a href="profile.php?id=<?php echo (int)$user['id'];?>">
                      <i class="glyphicon glyphicon-user"></i>
                      Profile
                  </a>
              </li>
             <li>
                 <a href="edit_account.php" title="edit account">
                     <i class="fa fa-cogs"></i>
                     Settings
                 </a>
             </li>
             <li class="last">
                 <a onClick = "logout();">
                     <i class="glyphicon glyphicon-off"></i>
                     Logout
                 </a>
             </li>
           </ul>
          </li>
        </ul>
		
      </div>
	  
	  <div class="pull-right clearfix">
        <ul class="info-menu list-inline list-unstyled">
          <li>
            <a href="messages.php" title = "Messages" data-toggle = "tooltip" data-placement ="bottom" style = "text-decoration:none; color:black;">
			<i class="fas fa-envelope fa-fw"></i>
            <sup class = "badge badge-danger" style = "background-color:red"><?php echo $messages['total'];?>+<sup>
            </a>
           
           </ul>
          </li>
        </ul>
      </div>
	   <div class="pull-right clearfix">
        <ul class="info-menu list-inline list-unstyled">
          <li>
            <a href="acts_log.php" title = "User acts Notifier" data-toggle = "tooltip" data-placement ="bottom" style = "text-decoration:none; color:black">
			<i class="fas fa-comments fa-fw"></i>
            <sup class = "badge badge-danger" style = "background-color:red"><?php echo $acts['total'];?>+<sup>
            </a>
           
           </ul>
          </li>
        </ul>
      </div>
     </div>
	 
     </div>
    </header>
    <div class="sidebar" style ="background:url('../images/bg_body.jpg')">
		<?php include ('admin_menu.php'); ?>
       
   </div>
<?php endif;?>

<div class="page" style = "background:url('../images/bg_body.jpg')">
  <div class="container-fluid">
  
 
   <script type="text/javascript">
function logout(){
sweetAlert({   title: "Are you sure you want leave?",
                                text: "You will be logged out!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonText: "Logout!",
                                cancelButtonText: "Cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="logout.php";   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
}
</script>	
 