<?php
	require_once "includes/load.php";
        $id = $_GET['id'];	
         $patient_info = find_by_id('patients', $id);
        $user = current_user();
        $docId = $user['id'];	
        $all_medicine = find_all('medicine');		
		?>
<?php
      if(isset($_POST['add_med_lab'])) {
		  
		   $req_field = array('medicine', 'amount');
           validate_fields($req_field);
		  
 		     $patient_id = $_POST['patient_id'];
			 $patient_type = $_POST['patient_type'];
			 $medicine_id = $_POST['medicine_id'];
		     $medicine_name = remove_junk ($db->escape($_POST['drug_name']));
		     $medicine= remove_junk ($db->escape($_POST['medicine']));

			 $amount = remove_junk ($db->escape($_POST['amount']));
			 $medication_info = find_med_by_patient_id ($patient_id);
			 $medStatement = $medication_info['medical'];
			 $medStatement .= $medicine_name . ': '.$amount. ' ,';


			 if(empty($errors)){	
           		 

           $sql = "UPDATE medication SET status = 'pharmacy', type = '{$patient_type}' ,medical = '{$medStatement}', doctor = '{$docId}' WHERE patient_id = '{$patient_id}'";
           $result = $db->query($sql);		  
          if($result)
		  {
		    $updateMedicineAmount = update_medicine_quantity ($medicine_id, $amount);
			
			insert_act('symptoms and test suggestions', 'updated', '1');

            $session->msg('s',"Patient Updated ");
            redirect('doc_patients.php', false);
          } else {
			insert_act('symptoms and test suggestions', 'updated', '0');
            $session->msg('d',' Sorry failed to updated!');
            redirect('doc_patients.php', false);
          }
     } 
	 else 
	 {
		 $session->msg ("d", $errors);
		 $redirect ("doc_patients.php", false);
	 }
	  }
?>
    <?php
	include('doctor_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Reception</a>
            </li>
            <li class="breadcrumb-item active">Manage Patients</li>
			<li class="breadcrumb-item active">All Patients</li>
          </ol>
		</div>
		
		
        <div class="row">
		<!-- start with table of users -->
	<!-- end table of  users --->
          <div class="col-md-12 employeeform">
            <p id="message"></p>
<h3>Assign Medicine to <?php echo $patient_info['fname']. ' '.$patient_info['sname']; ?></h3>

 <form method = "post" action = "add_med_lab.php">
	<table class="table table-striped">
	

	<tr>
	<th>
	<label> Medicine </label>
	<select class = "form-control"name = "medicine">
	<option value = "" > Select Medicine </option>
	<?php  foreach($all_medicine as $a_drug):
	  if (is_drug_enough ($a_drug['id']) AND is_drug_fresh($a_drug['id'])): ?>
	  
	<option value = "<?php echo $a_drug['id']?>"> <?php echo $a_drug['name']; ?> </option>
<th><input  class = "form-control" type = "text" style = "display:none;"name = "drug_name" value = "<?php echo $a_drug['name']?>"></th>

	<?php endif; ?>
	
	 <th><input  class = "form-control" type = "number" style = "display:none;"name = "medicine_id" value = "<?php echo $a_drug['id']?>"></th>

	<?php endforeach; ?>
	</select>
	</th>
	   <td> <label for = "name">Quantity </label> <input class = "form-control" name = "amount" type = "number"></td>
	 </th>
<td>	<label> Patient Type </label> 
   <select class ="form-control" type = "number" name = "patient_type">
   <option value = "" > Select Patient Type </option>
   <option value ="1"> Outpatient </option>
   <option value = "2"> Admitted </option>
   </select>
</td>  


		 <td><label> &nbsp;</label><button class = "btn btn-success form-control" type = "submit" name = "add_med_lab">Submit Medicine</td>
	
   </tr>
  
 <tr>
 <th><input  class = "form-control" type = "number" style = "display:hidden;"name = "patient_id" value = "<?php echo $patient_info['id']?>"></th>

   
   
   </tr>

		
		<!--end of main form -->
		
		
	</table>
	</form>
	
	
	
	


