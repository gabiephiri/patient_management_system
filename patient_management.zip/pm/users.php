<?php include ('includes/load.php');
$page_title = "System Users";
 page_require_level(1);
 $all_users = find_all_user();
 ?>
<?php include ('header.php'); ?>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Admin</a>
            </li>
            <li class="breadcrumb-item active">Manage Users</li>
          </ol>



        

          <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-users"></i>
              All Users</div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
					<th>#</th>
                      <th class = "text-center">Name</th>
					   <th class = "text-center">Username</th>
                      <th class = "text-center">Role</th>
					  <th class = "text-center">Department</th>
                      <th class = "text-center">Status</th>
                      <th class = "text-center">Last Login</th>
					   <th class = "text-center">Actions</th>
                    </tr>
                  </thead>
                  <tfoot>
				  <tr>
				      <th># </th>
					 <th class = "text-center">Username</th>
                      <th class = "text-center">Username</th>
                      <th class = "text-center">Role</th>
					  <th class = "text-center"> Department </th>
                      <th class = "text-center">Status</th>
                      <th class = "text-center">Last Login</th>
					  <th class = "text-center">Actions</th>
                    </tr>
                    
                  </tfoot>

                  <tbody>
				<?php foreach($all_users as $a_user): ?>
          <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td class = "text-center"><?php echo remove_junk(ucwords($a_user['name']))?></td>
           <td class = "text-center"><?php echo remove_junk(ucwords($a_user['username']))?></td>
           <td class="text-center"><?php echo remove_junk(ucwords($a_user['group_name']))?></td>
		              <td class="text-center"><?php echo remove_junk(ucwords($a_user['deptName']))?></td>

           <td class="text-center">
           <?php if($a_user['status'] === '1'): ?>
            <span class="label label-success"><?php echo "Active"; ?></span>
          <?php else: ?>
            <span class="label label-danger"><?php echo "Deactive"; ?></span>
          <?php endif;?>
           </td>
           <td><?php echo read_date($a_user['last_login'])?></td>
           <td class="text-center">
             <div class="btn-group">
                <a href="edit_user.php?id=<?php echo (int)$a_user['id'];?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                  <i class="fa fa-edit"></i>
               </a>
                <a href="delete_user.php?id=<?php echo (int)$a_user['id'];?>" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                  <i class="fa fa-trash"></i>
                </a>
                </div>
           </td>
          </tr>
        <?php endforeach;?>
       </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

       

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
  
