<?php
	require_once "includes/load.php";
        $id = $_GET['id'];	
         $patient_info = find_by_id('patients', $id);
        $user = current_user();
        $docId = $user['id'];		
		?>
<?php
      if(isset($_POST['submit_med_price'])) {
		  
		   $req_field = array('medicine_price', 'intake_instructions');
           validate_fields($req_field);
		  
 		     $patient_id = $_POST['patient_id'];	
			 $medication_info = find_med_by_patient_id($patient_id);
			 $room_number = $medication_info ['room_number'];


			 if(empty($errors)){	
		   $medicine_price = remove_junk ($db->escape($_POST['medicine_price']));
		   $intake_instructions = remove_junk ($db->escape($_POST['intake_instructions']));
           $sql = "UPDATE medication SET status = 'finish', medical_price= '{$medicine_price}', doctor = '{$docId}', intake_instructions = '{$intake_instructions}' WHERE patient_id = '{$patient_id}'";
			
			
          $result = $db->query($sql);
          if($result)
		  {
		     release_a_room($room_number);
			insert_act('medicine cost and intake directions', 'charged', '1');

            $session->msg('s',"medicine cost and intake instructions set successfully ");
            redirect('pharm_patients.php', false);
          } else {
			insert_act('medicine cost', 'charged', '0');
            $session->msg('d',' Sorry failed to charge and/or give instructions to patient!');
            redirect('pharm_patients.php', false);
          }
     } 
	 else 
	 {
		 $session->msg ("d", $errors);
		 $redirect ("pharm_patients.php", false);
	 }
	  }
?>
    <?php
	include('pharmacy_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Doctor</a>
            </li>
            <li class="breadcrumb-item active">Assign Medicine</li>
			<li class="breadcrumb-item active">All Patients</li>
          </ol>
		</div>	
        <div class="row">
		<!-- start with table of users -->
		-
	<!-- end table of  users --->
          <div class="col-md-12 employeeform">
            <p id="message"></p>
Assign Medicine to <?php echo $patient_info['fname']. ' '.$patient_info['sname']; ?> <br />
			<?php  $medication_info = find_med_by_patient_id($patient_info['id']); 
			     $prescribedMedicine = $medication_info ['medical']; 
			
			?>

Suggested Medicine (Medicine : Amount) ::> <b><?php echo $prescribedMedicine ?> </b>

 <form method = "post" action = "add_med_price.php">
	<table class="table table-striped">
	

	<tr colspan = "2">
	   <th><input name = "intake_instructions" type = "text" class = "form-control" placeholder = "Prescription Instructions" value = ""></th>

	<th><input name = "medicine_price" type = "number" class = "form-control" placeholder = "Total Medicine Price" value = ""></th>

  
	 <th><button class = "btn btn-success" type = "submit" name = "submit_med_price">Submit Medicine Price</th>
	  <th><input  class = "form-control" type = "number" style= "display:none"name = "patient_id" value = "<?php echo $patient_info['id']?>"></th>


			
   </tr>

 <tr>

   
   
   </tr>

		
		<!--end of main form -->
		
		
	</table>
	</form>
	
	
	
	


