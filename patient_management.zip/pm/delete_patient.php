
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
?>
<?php
  $delete_id = delete_by_id('patients',(int)$_GET['id']);
  if($delete_id){
	  insert_act('patient account', 'updated', '1');
      $session->msg("s","patient deleted.");
      redirect('manage_patients.php');
  } else {
	  insert_act('patient account', 'updated', '0');
      $session->msg("d","patient deletion failed Or Missing Prm.");
      redirect('manage_patients.php');
  }
?>
