 
<?php include("includes/load.php");
$all_medicine= find_all('medicine');
$count_medicine = count_by_id ('medicine');
$medicine_count = $count_medicine['total'];
$user = current_user ();
$expired_count = $medicine_count - count_fresh_medicine();
 ?>
  <?php
 if(isset($_POST['add_medicine'])){
   $req_field = array('name', 'price', 'amount', 'expiry_date');
   validate_fields($req_field);
   
   $name = remove_junk ($db->escape($_POST['name']));
      $price = remove_junk ($db->escape($_POST['price']));
	   $amount = remove_junk ($db->escape($_POST['amount']));
	   $least_amount= remove_junk ($db->escape($_POST['least_amount']));
		$expiry_date = remove_junk ($db->escape($_POST['expiry_date']));
		$last_touched = make_date();
							  





   if(empty($errors)){
      $sql  = "INSERT INTO medicine(name, price,amount, least_amount, expiry_date, last_touched)";
      $sql .= " VALUES ('{$name}','{$price}', '{$amount}', '{$least_amount}', '{$expiry_date}', '{$last_touched}' )";
      if($db->query($sql)){
		  insert_act('medicine', 'added', '1');
        $session->msg("s", "Successfully added medical drug");
        redirect('manage_medicine.php',false);
      } else {
		  		  insert_act('medicine', 'added', '0');

        $session->msg("d", "Sorry failed to add medicine.");
        redirect('manage_medicine.php',false);
      }
   } else {
     $session->msg("d", $errors);
     redirect('manage_medicine.php',false);
   }
 }
?>
    <?php
	include('pharmacy_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="pharm_patients.php">Pharmacist</a>
            </li>
            <li class="breadcrumb-item active">Manage Medicine</li>
			 <li class="breadcrumb-item active">All</li>

			

            </li>

          </ol>
		</div>
		
		<div class="page-header">
       <ol class="breadcrumb">
	   
	               
            <li class="breadcrumb-item active"><b> <?php echo 'All Medicine : ' . $medicine_count. ' Drugs Expired : '.$expired_count . ' Medicine in Low Supply : '.count_low_sup_med();?></b>
	
			</li>
			
          </ol>
		</div>
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-7">
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Price</th>
				  				 <th>Remaining</>

				  <th>Expiry</>

                   <th>Actions</th>

				 
              </thead>
			    <tfoot>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Price</th>
				    <th>Remaining</th>
					<th>Expiry</th>


                  <th> Actions</th>
				 
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($all_medicine as $a_drug): 
	  ?>

		<tr class='prev' id="pre<?php echo $a_drug['id']?>">
      <td><?php echo count_id() ?></td>
       <td><?php echo $a_drug['name'] ?></td>
		<td><?php echo number_format($a_drug['price'], 2) ?></td>
				<td><?php echo number_format($a_drug['amount'], 2) ?></td>
						<td><?php echo read_date_only($a_drug['expiry_date']) ?></td>


        
		<td>
		<div class='btn btn-info btn-xs view-button' did='<?php echo $a_drug['id']?>'><i class = 'fa fa-info' title = "info & create new"data-toggle = "tooltip" data-placement="bottom"></i></div>
			 <div class='btn btn-warning edit-button btn-xs' xid ='<?php echo $a_drug['id']?>'><i class = 'fa fa-edit'  title = "edit"data-toggle = "tooltip" data-placement="bottom"></i></div>

                 <button class = 'btn btn-danger'onclick = "deleteMedicine(<?php echo $a_drug['id']?>)" class="btn btn-danger"  title="Delete" data-toggle="tooltip">
                  <span class="fa fa-trash"></span></button> 

         </tr>
	<?php endforeach; ?>

			  
		
			  
			  </tbody>		
         </table>

          </div>
		
		
		
		<!-- end table of  users --->
          <div class="col-md-5 employeeform" style = "display:none;">
            <p id="message"></p>
            <form method="post" action = "manage_medicine.php">
             <table class="table table-striped">
		
		
		<tr>
		<th> Medicine Name </th>
             <td> <input type="text" name="name" class="form-control" placeholder="Medicine Name" required></td>
	     </tr>
        <tr>
			<th> Medicine Cost </th>		 
			<td><input type="number"  name="price" class="form-control"  required></td>
		</tr>
		<tr>
			<th> Quantity </th>		 
			<td><input type="number"  name="amount" class="form-control"  required></td>
		</tr>
		<tr>
			<th> Least Quantity<br>Notify </th>		 
			<td><input type="number"  name="least_amount" class="form-control"  required></td>
		</tr>
		<tr>
			<th> Expiry Date </th>		 
			<td><input type="text" placeholder = "select date" onfocus = "this.type='date'"  name="expiry_date" class="form-control"  required></td>
		</tr>
		
		<tr>
		<td> <button type = "submit" name = "add_medicine" class = "btn btn-success pull-right">Add Medicine</td>
		</tr>
		
		
			
	</table>
            </form>
          </div>
          <div class="col-md-5 viewemployee" style="display:none;"></div>

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   <script> 
      $(document).ready(function(){


        //View Employee
        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "medicine_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
		
		  //View Employee
        $(document).on('click', '.edit-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("xid"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "edit_medicine.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		

		 function deleteUser(x){
           sweetAlert({   title: "Pharmacist  <?php echo $user['last_name']?>  do you really want to delete medicine?!",
                                text: "medicine  will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_medicine.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } 
										  
					});
		
		 

		 }
		
		
	
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">

		 function deleteMedicine(x){
           sweetAlert({   title: "Pharmacist  <?php echo $user['last_name']?> do you really want to delete the medicine?!",
                                text: "medicine  will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_medicine.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } 
							 });
}
</script>
  </body>
  
</html>
