<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	$patient_info = find_by_id ('patients', $id);
	$select_medic_info_query = "SELECT * FROM  medication WHERE patient_id = '{$id}' ORDER BY date_updated DESC LIMIT 1";
	$executeMedInfo = $db->query($select_medic_info_query);
    $med_info = mysqli_fetch_assoc($executeMedInfo);
	
	$test_sug = $med_info['tests'];
	$test_results= $med_info['test_results'];

?>
	<table class="table table-striped">
		
		
		<tr>
			<th>Name</th>
			<td> <?php echo $patient_info['fname'] ?> <?php echo $patient_info['sname'] ?></td>
		</tr>

		<?php if (!is_null($patient_info['email'])) :?>
		<tr>
			<th><i class = "fa fa-envelope">  Email</th>
			<td>
			
			<?php echo  $patient_info['email']; ?>
			</td>
		</tr>
		<?php endif; ?>
		<?php if (!is_null($patient_info['phone'])):?></td>
		<tr>
		<th><i class = "fa fa-phone"> </i>  Phone</th>
		<td>
              <?php echo $patient_info['phone']; ?>
		</td>
		</tr>
		
		<?php endif; ?>
		
		<tr>
		
			<th>Blood Group</th>
			<td><?php echo strtoupper($patient_info['bloodgroup']);?></td>
		</tr>
		<tr>
		
			<th>Test Symptoms</th>
			<td><?php echo strtoupper($test_sug);?></td>
		</tr>
		<tr>
		
			<th>Test Suggestions</th>
			<td><?php echo strtoupper($test_results);?></td>
		</tr>
		<tr>
			<th>Birth Year</th>
			<td> <?php echo $patient_info['birthyear'] ?>  </td>
		</tr>
		<tr>
			<th><i class = "fa fa-calendar"> </i>  Date of Recording</th>
			<td> <?php echo read_date ($patient_info['dateadded'])?>  </td>
		</tr>
		
	</table>


