<?php
	include "includes/load.php";
       $id = $_GET['sid'];			
		$patient_info = find_by_id('patients', $id);

    	
		$patient_id = $patient_info['id'];	

		 
		$findMedQuery = "SELECT * FROM medication WHERE patient_id = '{$id}' ORDER BY id LIMIT 1";
		$executeMedQuery = $db->query($findMedQuery);
		$medRows= mysqli_fetch_array($executeMedQuery);
		$docId = $medRows['doctor'];
		
		$find_med_doc_info = find_by_id ('users', $docId);
		$assignedDoc = $find_med_doc_info['first_name']. ' '. $find_med_doc_info['last_name'];

		$all_doctors = users_in_group ('doc');
		?>
<?php
      if(isset($_POST['assign_doc'])) {
 		$patient_id = $_POST['patient_id'];	

		   $doctor = remove_junk ($db->escape($_POST['doctor']));
		   	$doctor_price = remove_junk ($db->escape($_POST['doctor_price']));

					  

         $sql = "INSERT INTO medication (patient_id, status, doctor_price, doctor)VALUES ('{$patient_id}','recdoctor', '{$doctor_price}','{$doctor}')";
			
			$db->query($sql);
			
          $result = $db->query($sql);
          if($result)
		  {
			  			insert_act('patient', 'updated', '1');

            $session->msg('s',"Patient Updated ");
            redirect('manage_patients.php', false);
          } else {
			insert_act('patient', 'updated', '0');
            $session->msg('d',' Sorry failed to updated!');
            redirect('manage_patients.php', false);
          }
    } 
  
?>

	
	
	
	
	
 <form method = "post" action = "assign_doc.php">
	<table class="table table-striped">
            <tr>
	            <th><a class="btn btn-primary" href = "doctor_prices.php">Default Doctor Prices</a></th>
	  </tr>
		
		<tr>
				<th> Assign Doc  Now : <?php if (!is_null($assignedDoc))echo $assignedDoc ?></th>

			<td>
			<select class="form-control" name="doctor">
				
			
			
			<?php foreach ($all_doctors as $a_doc):?> 
                  <option <?php if($a_doc['id'] === $docId) echo 'selected="selected"';?>value="<?php echo $a_doc['id']?>"><?php echo $a_doc['first_name']. ' '. $a_doc['last_name']?></option>

			<?php endforeach;?>
			<?php
			?>
		
                </select>	
		   </td>
		   </tr>
		   <th>Doctor Price </th>
		 <td> <input name = "doctor_price" type = "number" class = "form-control"></td>
		 </tr>
		 
	                 <tr><th><input name = "patient_id" type = "number" class = "form-control" style ="visibility:hidden"value = "<?php echo $patient_info['id']; ?>"></th>
				
							<td><button class = "btn btn-success" type = "submit" name = "assign_doc">Assign Doc</td>


		</tr>

		
		<!--end of main form -->
		
		
	</table>
	</form>
	
	
	
	


