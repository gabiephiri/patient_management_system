<?php
	include "includes/load.php";
		$id = $_GET['asdid'];	
		$user_info = find_by_id('users', $id);	
		$user_id = $user_info['id'];
		$all_user_groups = find_all('user_groups');	
		$all_doctor_types = find_all('doctor_types');
		
		
?>

<?php
//Update User basic info
  if(isset($_POST['assign_type'])) {
    $req_fields = array('doctor_type');
    validate_fields($req_fields);
    if(empty($errors)){
         $doctor_id = (int) $_POST['doctor_id'];
		    $doctor_type = remove_junk($db->escape($_POST['doctor_type']));
           
			$checkDoctorExists = "SELECT * FROM doctors WHERE userId = '{$doctor_id}' AND type = '{$doctor_type}'";	
               if ($checkDoctorExists){
			   
				 $sql = "INSERT INTO doctors (userId, type) VALUES ('{$doctor_id}', '{$doctor_type}')";
				 $result = $db->query($sql);
				  if($result){
				   insert_act('doctor', ' assigned type', '1');

					$session->msg('s',"doctor successfully assigned type ");
					redirect('manage_users.php', false);
				  } else {
					insert_act('doctor', 'assigned type', '0');
					$session->msg('d',' Sorry failed to assign a doctor type!');
					redirect('manage_users.php', false);
          }
    } 
	
	else 
	{
	   $updateDoctorType = "UPDATE doctors SET type = {$doctor_type} WHERE userId = '{$doctor_id}'";
	    $updateResult = $db->query($updateDoctorType);
          if($updateResult && $db->affected_rows() === 1){
			  			insert_act('doctor', 'updated', '1');

            $session->msg('s',"Doctor Type Updated successfully ");
            redirect('manage_users.php', false);
          } else {
			insert_act('Doctor type', 'updated', '0');
            $session->msg('d',' Sorry failed to update doctor type!');
            redirect('manage_users.php', false);
          }
	}
	}
	else {
      $session->msg("d", $errors);
      redirect('manage_users.php',false);
    }
  }
?>
 <form method = "post" action = "as_doctor.php?asdid=<?php echo $user_info['id']?>">
	<table class="table table-striped">
	

	   <tr style = "background-color:yellowgreen">
	   <th colspan = '3'> Assign Doctor Type</th>
	   </tr>
		<tr>
		
		 <th>Name :</th><td> <?php echo $user_info ['title']. ' '. $user_info['first_name']. ' '.$user_info['other_names']. ' '.$user_info['last_name']; ?></td>
		 <?php  
		 $doctor_info = find_by_doc_id($id);
		  $doc_type_info = find_by_id('doctor_types', $doctor_info['type']);
		  $doc_type_name = $doc_type_info['name'];
		  
		?>
          </tr>
		 <tr>
			<th>Doctor Type</th>
		 <td>   <select class="form-control" name="doctor_type">
                  <?php foreach ($all_doctor_types as $a_doc_type ):?>
                   <option <?php if($doctor_info['type'] === $a_doc_type['id']) echo 'selected="selected"';?> value="<?php echo $a_doc_type['id'];?>"><?php echo ucwords($a_doc_type['name']);?></option>
                <?php endforeach;?>
                </select>
		</tr>
		
			<tr>
			<th> </th>
               <td colspan = "2"> <button class = "btn btn-success" name = "assign_type"> Assign Type</td>

			    <td> <input type = 'number' value = "<?php echo $user_info['id']?>" name = "doctor_id" style = "display:none;"> </td>

            <tr>			
		
	
	</table>
	</form>	
	
	


<?php
// Update user password
if(isset($_POST['update_password'])) {
  $req_fields = array('password');
  validate_fields($req_fields);
  if(empty($errors)){
           $id = (int)$user_info['id'];
     $password = remove_junk($db->escape($_POST['password']));
     $h_pass   = sha1($password);
          $sql = "UPDATE users SET password='{$h_pass}' WHERE id='{$db->escape($id)}'";
       $result = $db->query($sql);
        if($result && $db->affected_rows() === 1){
			insert_act('password', 'changed', '1');
          $session->msg('s',"User password has been updated ");
          redirect('manage_users.php', false);
        } else {
		  insert_act('password', 'changed', '0');
          $session->msg('d',' Sorry failed to updated user password!');
          redirect('manage_users.php', false);
        }
  } else {
    $session->msg("d", $errors);
    redirect('manage_users.php',false);
  }
}
?>

