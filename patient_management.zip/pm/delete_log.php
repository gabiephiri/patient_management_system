<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(1);
?>
<?php 
  
  
   $clearLogQuery = "TRUNCATE acts_log";
   $executeClear = $db->query($clearLogQuery);
 if($executeClear){
	  insert_act('log', 'cleared', '1');
      $session->msg("s","Log cleared.");
      redirect('acts_log.php');
  } 
  else {
	  insert_act('log', 'cleared', '0');
      $session->msg("d","Log clearing failed.");
      redirect('acts_log.php');
  }
  
?>