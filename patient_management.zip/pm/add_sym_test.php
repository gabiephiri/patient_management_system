<?php
	require_once "includes/load.php";
        $id = $_GET['eid'];	
         $patient_info = find_by_id('patients', $id);		
		?>
<?php
      if(isset($_POST['add_sym_test'])) {
		  
		   $req_field = array('symptoms', 'test_suggestions');
           validate_fields($req_field);
		  
 		     $patient_id = $_POST['patient_id'];	

		   $symptoms = remove_junk ($db->escape($_POST['symptoms']));
		   	$test_suggestions = remove_junk ($db->escape($_POST['test_suggestions']));

			 if(empty($errors)){		  

                  $sql = "UPDATE medication SET status = 'labdoctor', symptoms = '{$symptoms}', tests = '{$test_suggestions}' WHERE patient_id = '{$patient_id}'";
			
			
          $result = $db->query($sql);
          if($result)
		  {
		  
			insert_act('symptoms and test suggestions', 'updated', '1');

            $session->msg('s',"Patient Updated ");
            redirect('add_sym_test.php?eid='.$patient_id, false);
          } else {
			insert_act('symptoms and test suggestions', 'updated', '0');
            $session->msg('d',' Sorry failed to updated!');
            redirect('doc_patients.php?eid='.$patient_id, false);
          }
     } 
	 else 
	 {
		 $session->msg ("d", $errors);
		 $redirect ("doc_patients.php", false);
	 }
	  }
?>

	
	
	
	
	
 <form method = "post" action = "add_sym_test.php">
	<table class="table table-striped">
	
	<tr colspan = "2">
     <td><textarea name = "symptoms" type = "text" class = "form-control" placeholder= "Add Symptoms"></textarea></td>

		   </tr>
	<tr colspan = "2">
	<th><textarea name = "test_suggestions" type = "text" class = "form-control" placeholder = "Add Test Suggestion" value = ""></textarea></th>
			
   </tr>
   <tr>
    
 <th><button class = "btn btn-success" type = "submit" name = "add_sym_test">Submit Symptoms &amp; Test Suggestions</th>
 </tr>
 <tr>
 <th><input  class = "form-control" type = "number" name = "patient_id" value = "<?php echo $patient_info['id']?>"></th>

   
   
   </tr>

		
		<!--end of main form -->
		
		
	</table>
	</form>
	
	
	
	


