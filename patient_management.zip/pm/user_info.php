<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	
	$user_info = find_by_id('users', $id);	
	$user_group = $user_info['user_level'];
	$group_info = find_by_id ('user_groups', $user_group);
    $group_name = $group_info['group_name'];

?>
	<table class="table table-striped">
		<tr class = "pull-right">
            <th><button class="btn btn-primary addEmployee">Add User</button></th>
            <td></td>
		</tr>
		
		<tr>
			<th>Name</th>
			<td><?php echo $user_info['title']; ?> <?php echo $user_info['first_name'] ?> <?php echo $user_info['other_names'] ?> <?php echo $user_info['last_name'] ?></td>
		</tr>
		
		<tr>
			<th>User Name</th>
			<td><?php echo $user_info['username']; ?></td>
		</tr>
		<tr>
			<th>Email Address</th>
			<td><?php echo $user_info['email_address']; ?></td>
		</tr>
		
		<tr>
			<th>Role</th>
			<td><?php echo $group_name ?></td>
		</tr>
		<tr>
			<th>Status</th>
			<?php if ($user_info['status'] === '1') :?>
			<td>Active</td>
			<?php else : ?>
						<td>Inactive</td>
          <?php endif; ?>
		</tr>
		<tr>
			<th>Phone No</th>
			<td><?php echo $user_info['phone_number']; ?></td>
		</tr>
		<tr>
	<?php	if (!is_null ($user_info['last_login'])) :?>
			<th>Last Login</th>
		
			<td><?php echo read_date($user_info['last_login']); ?></td>
			<?php endif; ?>
		</tr>
	</table>

