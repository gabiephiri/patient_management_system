<?php
	include "includes/load.php";
		$id = $_GET['eid'];	
		$doc_type_info = find_by_id('doctor_types', $id);	
		
		
		
?>

<?php
//Update User basic info
  if(isset($_POST['change_price'])) {
    $req_fields = array('doc_type_price');
    validate_fields($req_fields);
    if(empty($errors)){
         $doc_type_id = (int) $_POST['doctor_type_id'];
		    $doc_type_price = remove_junk($db->escape($_POST['doc_type_price']));
          
			   
				 $sql = "UPDATE doctor_types SET price = '{$doc_type_price}' WHERE id = '{$doc_type_id}'";
				 $result = $db->query($sql);
				  if($result && $db->affected_rows() === 1){
								insert_act('doctor group', ' price changed', '1');

					$session->msg('s',"doctor group price successfully updated ");
					redirect('doctor_prices.php', false);
				  } 
				  else {
					insert_act('doctor group price', 'updated', '0');
					$session->msg('d',' Sorry failed to update doctor price!');
					redirect('doctor_prices.php', false);
          }
    } 
	
	
	else {
      $session->msg("d", $errors);
      redirect('doctor_prices.php',false);
    }
  }
?>
 <form method = "post" action = "set_doc_price.php?id=<?php echo $doc_type_info['id']?>">
	<table class="table table-striped">
	
	   <tr style = "background-color:yellowgreen">
	   <th colspan = '3'> Assign Doctor Price</th>
	   </tr>
		<tr>
		
		 <th>Type:</th><td><?php echo $doc_type_info['name']; ?></td>
          </tr>
		 <tr>
			<th>Doctor Type</th>
		 <td> <input type = 'number' value = "<?php echo $doc_type_info['price']?>" name = "doc_type_price"> </td>

		</tr>
		
			<tr>
			<th> </th>
               <td colspan = "2"> <button class = "btn btn-success" name = "change_price"> Assign Type</td>

			    <td> <input type = 'number' value = "<?php echo $doc_type_info['id']?>" name = "doctor_type_id" style = "display:none;"> </td>

            <tr>			
		
	
	</table>
	</form>	
	
	

