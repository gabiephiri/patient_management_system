This project is developed using PHP and MySQL.
To use it , do the following:
1. Download the package as a zip file
2. Extract it to your root directory ... for example if assuming you are running this locally using WAMP on a 64-bit Windows Machine, and the new directory being pm, then the resultant path will be something like 'C:\Wamp64\www\pm;
3. The database driving the system is named patients.sql AND is located in the root project folder ie 'pm/patients.sql'... Go ahead and import this in your database server using a database name of your choice.
4. The database connection configuration file is contained in pm/includes and it is named 'config.php'...Go ahead and edit it to suit your database login credentials for the user. The defaults in the file are 
                         
						  define( 'DB_HOST', 'localhost' );          // Set database host
						  define( 'DB_USER', 'root' );             // Set database user
						  define( 'DB_PASS', '' );             // Set database password
						  define( 'DB_NAME', 'patients' );     
  
  
5. if you have done the above, then you have successfully installed the system
Now go ahead and type the path to the system in the web browser... using the above assumptions, the path should be 'C:\Wamp64\www\pm'... This will bring the login screen awaiting credentials... 
6. ALL THE LOGIN CREDENTIALS ARE CONTAINED IN A PDF FILE CALLED "PATIENT MANAGEMENT SYSTEM LOGIN CREDENTIALS"
7. Login and Enjoy!