
<?php
  require_once('includes/load.php');
?>
<?php
  $delete_id = delete_by_id('rooms',(int)$_GET['id']);
  if($delete_id){
	  insert_act('room', 'deleted', '1');
      $session->msg("s","room deleted successfully.");
      redirect('rooms.php');
  } else {
	  insert_act('room', 'deleted', '0');
      $session->msg("d","room deletion failed Or Missing Prm.");
      redirect('rooms.php');
  }
?>
