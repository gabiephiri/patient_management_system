 
<?php
require_once("includes/load.php");
$all_patients = find_all('patients');
$count_patients = count_by_id('patients');
$total_patients = $count_patients['total'];
$page_title = 'Manage Patients';


$last_patient_id = "SELECT MAX(id) as last_id FROM patients";
$executeLastId = $db->query($last_patient_id);
$row = mysqli_fetch_assoc($executeLastId);
$lastId = $row['last_id'];
$freshPatientId = (int)$lastId + 1;


$selectPediatrician = "SELECT * FROM doctors WHERE type = '3' LIMIT 1";
$executeSelectPed = $db->query($selectPediatrician);
$pedRow = mysqli_fetch_array($executeSelectPed);
$pedId = $pedRow['id'];

$getPedPrice = "SELECT * FROM doctor_types WHERE id = '3'";
$executePrice = $db->query($getPedPrice);
$priceRow = mysqli_fetch_array($executePrice);
$pedPrice = $priceRow['price'];
 ?>
  <?php
 if(isset($_POST['submit_patient'])){
   $req_field = array('first_name', 'last_name', 'sex', 'birth_year');
   validate_fields($req_field);
   $first_name = remove_junk($db->escape($_POST['first_name']));
   $last_name = remove_junk($db->escape($_POST['last_name']));
   $email_address = remove_junk($db->escape($_POST['email_address']));
   $phone_number = remove_junk($db->escape($_POST['phone_number']));
   $sex = remove_junk($db->escape($_POST['sex']));
   $blood_group = remove_junk($db->escape($_POST['blood_group']));
   $birth_year = remove_junk($db->escape($_POST['birth_year']));
   
    $thisYear = date ('Y');
	$age = (int) ($thisYear - $birth_year);
	
	
	
		 
   if(empty($errors)){
      $sql  = "INSERT INTO patients ( fname, sname,  email, phone, sex, bloodgroup, birthyear)";
      $sql .= " VALUES ('{$first_name}', '{$last_name}','{$email_address}','{$phone_number}', '{$sex}', '{$blood_group}', '{$birth_year}')";
	  
	  
	  
	  
      if($db->query($sql)){
	   if ($age <=13)
		 {
		    $assignPed = "INSERT INTO medication (patient_id, doctor, doctor_price) VALUES ('{$freshPatientId}', '{$pedId}', '{$pedPrice}')";
			$db->query($assignPed);
		 }
		  insert_act('patient', 'added', '1');
        $session->msg("s", "Successfully added patient");
        redirect('manage_patients.php',false);
		 
		 
		
      } else {
		  		  insert_act('patient', 'added', '0');

        $session->msg("d", "Sorry failed to create user.");
        redirect('manage_patients.php',false);
      }
   } else {
     $session->msg("d", $errors);
     redirect('manage_patients.php',false);
   }
 }
?>
    <?php
	include('nurse_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Reception</a>
            </li>
            <li class="breadcrumb-item active">Manage Patients</li>
			<li class="breadcrumb-item active">All Patients</li>
          </ol>
		</div>
		
		<div class="page-header">
       <ol class="breadcrumb">
	   
	   <?php 
	   
	   
	
	   ?>
            
            <li class="breadcrumb-item active"><b>All Patients : </b> <?php echo $total_patients; ?>
		
			</li>
			
          </ol>
		</div>
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-7">
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Sex</th>
				   <th>Room</th>

				   <th>Added</th>
                   <th>Actions</th>
				 
              </thead>
			    <tfoot>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Sex</th>
				   <th>Room</th>
				  <th>Added</th>
                  <th> Actions</th> 
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($all_patients  as $a_patient): 
	    if (is_outpatient($a_patient['id'])): 
	  $medication_info = find_med_by_patient_id($a_patient['id']);
	  $room_number = $medication_info['room_number'];
	  $room_info = find_by_id ('rooms', $room_number);
	  $room_name = $room_info ['name'];
	  ?>

		<tr class='prev' id="pre<?php echo $a_patient['id']?>">
      <td><?php echo count_id() ?></td>
       <td><?php echo $a_patient['fname']. ' '. $a_patient['sname'];?> </td>
		<td><?php echo $a_patient['sex'] ?></td>
		
		<td><?php echo $room_name; ?></td>

        <td><?php echo read_date($a_patient['dateadded']);?></td>
        
		<td>
		<div class='btn btn-info btn-xs view-button' did='<?php echo $a_patient['id']?>'><i class = 'fa fa-info' title = "info & create new"data-toggle = "tooltip" data-placement="bottom"></i></div>
		     <?php 
			  if (is_patient_roomless ($a_patient['id'])):
			   
			 
			 ?>
			  <div class='btn btn-warning assign-button btn-xs' nid ='<?php echo $a_patient['id']?>'><i class = 'fa fa-home'  title = "assign room to patient"data-toggle = "tooltip" data-placement="bottom"></i></div>

             <?php endif; ?>
                 <button class = 'btn btn-danger'onclick = "dischargePatient(<?php echo $a_patient['id']?>)" class="btn btn-danger"  title="Delete" data-toggle="tooltip">
                  <span class="fa fa-trash"></span></button> 
   
	 </td>
         </tr>
		 <?php endif; ?>
	<?php endforeach; ?>

			  
		
			  
			  </tbody>		
         </table>

          </div>
		
		
		
		<!-- end table of  users --->
          <div class="col-md-5 employeeform" style = "display:none;">
            <p id="message"></p>
            <form method="post" id="insert">
             <table class="table table-striped">
		
		
		<tr>
             <th> <input type="text" name="first_name" class="form-control" placeholder="First  Name " required></th>
			<td><input type="text" name="last_name" class="form-control" placeholder="Last Name " required></td>
		</tr>
		<tr>
		    <th> <input type="email_address" name="email_address" class="form-control" placeholder="Email Address" ></th>
			<td><input type="phone" name="phone_number" class="form-control" placeholder="Phone Number"></td>
		</tr>
		
		<tr>

			<td>
			
			 <select class="form-control" name="sex" required = "required">
				<option value = "">Select Gender</option> 
                   <option value="Female">Female</option>
				   <option value="Male">Male</option>
                </select>
			
			</td>
			
			<td>
			
			 <select class="form-control" name="blood_group" required = "required">
				<option value = "">Blood Group</option> 
                   <option value="A">A</option>
				   <option value="B">B</option>
				   <option value="AB">AB</option>
				   <option value="O">O</option>
                </select>
			
			</td>
			
		</tr>
		<tr>
		<th> Year of Birth </th>
		<td>
			
			 <select class="form-control" name="birth_year" required = "required" >
				<option value = "">Select </option> 
				
				<?php 
				
				$thisYear = date ('Y');
				$numberYear = (int) $thisYear;
				
				for($birthyear = 1920; $birthyear <= $thisYear; $birthyear++) :?>
                   <option value="<?php echo (int)$birthyear ?>"><?php echo $birthyear ?></option>
				   <?php endfor; ?>
                </select>
			
			</td>
		
		</tr>
		<tr>
			<th><button type="submit" name = "submit_patient"class="btn btn-block btn-info insertButton">Submit</button></th>
			
		</tr>
		<tr>
			
		</tr>
			
	</table>
            </form>
       </div>
          <div class="col-md-5 viewemployee" style="display:none;"></div>
		   <div class="col-md-5 doc_prices" style="display:none;">
		   <tr>
		  
			<th></th>
			<td><?php echo $user_info['username']; ?></td>
		</tr>
		   
		   
		   </div>


         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
   <script> 
      $(document).ready(function(){
       
        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "patient_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
		
		  //View Employee
        $(document).on('click', '.edit-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("xid"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "edit_patient.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
		
		//assign doc
		 $(document).on('click', '.assign-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("nid"); 
          var Data = {'sid':eid};
          $.ajax({
            url: "assign_room.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.docPrices', function(){ 
		  $('.doc_prices').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		//end assignment
		
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	

  </body>
  
</html>
