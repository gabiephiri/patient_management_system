<?php
	include "includes/load.php";
	$id = $_GET['eid'];
	$patient_info = find_by_id ('patients', $id);
	$select_medic_info_query = "SELECT * FROM  medication WHERE patient_id = '{$id}' ORDER BY date_updated DESC LIMIT 1";
	$executeMedInfo = $db->query($select_medic_info_query);
    $med_info = mysqli_fetch_assoc($executeMedInfo);
	$symptoms= $med_info['symptoms'];
	$tests = $med_info['tests'];
	$test_results = $med_info['test_results'];
	$test_price = $med_info['test_price'];
	$doctor_price = $med_info['doctor_price'];
	$medical_price = $med_info['medical_price'];

?>
	<table class="table table-striped">
	
		
		<tr>
		<th  colspan = "2" style = "background-color:white"><button class = "btn btn-success fa fa-print pull-right" onclick = "printElem('printable_part2');"></button>
       </th>
		<tr>
		<tr>
			<th>Name</th>
			<td> <?php echo $patient_info['fname'] ?> <?php echo $patient_info['sname'] ?></td>
		</tr>

		<?php if (!is_null($patient_info['email'])) :?>
		<tr>
			<th><i class = "fa fa-envelope">  Email</th>
			<td>
			
			<?php echo  $patient_info['email']; ?>
			</td>
		</tr>
		<?php endif; ?>
		<?php if (!is_null($patient_info['phone'])):?></td>
		<tr>
		<th><i class = "fa fa-phone"> </i>  Phone</th>
		<td>
              <?php echo $patient_info['phone']; ?>
		</td>
		</tr>
		
		<?php endif; ?>
		
		<tr>
		
			<th>Blood Group</th>
			<td><?php echo ucwords($patient_info['bloodgroup']);?></td>
		</tr>
		<tr>
		
			<th>Test Symptoms</th>
			<td><?php echo ucwords($symptoms);?></td>
		</tr>
		
		<tr>
		
			<th>Test Results</th>
			<td><?php echo ucwords($test_results);?></td>
		</tr>
		<tr style = "background:green;">
		
			<th>Test Price (MK)</th>
			<td><?php echo number_format($test_price, 2);?></td>
		</tr>
		<tr style = "background:blue;">
		
			<th>Doctor (MK)</th>
			<td><?php echo number_format($doctor_price, 2);?></td>
		</tr>
		
		<tr style = "background:lightgreen;">
		
			<th>Medicine Price (MK)</th>
			<td><?php echo number_format($medical_price, 2);?></td>
		</tr>
		
		
		<tr>
			<th>Birth Year</th>
			<td> <?php echo $patient_info['birthyear'] ?>  </td>
		</tr>
		<tr>
			<th><i class = "fa fa-calendar"> </i>  Date of Recording</th>
			<td> <?php echo read_date ($patient_info['dateadded'])?>  </td>
		</tr>
		
	</table>


