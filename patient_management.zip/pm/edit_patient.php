<?php
	include "includes/load.php";
		$id = $_GET['eid'];	
		$patient_info = find_by_id('patients', $id);	
		$patient_id = $patient_info['id'];	
        	 
?>

<?php
//Update User basic info
  if(isset($_POST['update_patient'])) {
    $req_fields = array('first_name','last_name','sex', 'blood_group');
    validate_fields($req_fields);
    if(empty($errors)){
         $patient_id = (int) $_POST['patient_id'];
           $first_name = remove_junk($db->escape($_POST['first_name']));
		   $last_name = remove_junk($db->escape($_POST['last_name']));
		   $email_address = remove_junk($db->escape($_POST['email_address']));
		  $phone_number = remove_junk($db->escape($_POST['phone_number']));
		  $sex = remove_junk($db->escape($_POST['sex']));
		   $blood_group = remove_junk($db->escape($_POST['blood_group']));
		   $birth_year = remove_junk($db->escape($_POST['birth_year']));
					  

         $sql = "UPDATE patients SET fname ='{$first_name}', sname ='{$last_name}', email = '{$email_address}', phone = '{$phone_number}', sex = '{$sex}',
			bloodgroup='{$blood_group}', birthyear = '{$birth_year}' WHERE id='{$patient_id}'";
			
			
         $result = $db->query($sql);
          if($result){
			  			insert_act('patient', 'updated', '1');

            $session->msg('s',"Patient Updated ");
            redirect('manage_patients.php', false);
          } else {
			insert_act('patient', 'updated', '0');
            $session->msg('d',' Sorry failed to updated!');
            redirect('manage_patients.php', false);
          }
    } else {
      $session->msg("d", $errors);
      redirect('manage_patients.php',false);
    }
  }
  
?>

 <form method = "post" action = "edit_patient.php">
	<table class="table table-striped">
	
		<tr>
		 
		
		<tr>
			<th>First Name</th>
		 <td> <input name = "first_name" type = "text" class = "form-control" value = "<?php echo $patient_info['fname'] ?>"></td>
		</tr>
		<tr>
	   <th>Last Name </th>
		 <td> <input name = "last_name" type = "text" class = "form-control" value = "<?php echo $patient_info['sname'] ?>"></td>
		 </tr>
		 
		
		  <th>Email Address </th>
		 <td> <input name = "email_address" type = "text" class = "form-control" value = "<?php echo $patient_info['email'] ?>"></td>
		 </tr>
		  <th>Phone Number </th>
		 <td> <input name = "phone_number" type = "text" class = "form-control" value = "<?php echo $patient_info['phone']; ?>"></td>
		 </tr>
		 <th>Gender </th>
		 <td><select class="form-control" name="sex">
				 <option <?php if($patient_info['sex'] === 'Female') echo 'selected="selected"';?>value="Female">Female</option>  
				 <option <?php if($patient_info['sex'] === 'Male') echo 'selected="selected"';?> value="Male">Male</option>
                </select>
			</td>
		 </tr>
		
		
		<tr>
		<th>Blood Group</th>
			<td><select class="form-control" name="blood_group">
                  
                  <option <?php if($patient_info['bloodgroup'] === 'A') echo 'selected="selected"';?>value="A">A</option>
                  <option <?php if($patient_info['bloodgroup'] === 'B') echo 'selected="selected"';?> value="B">B</option>
				   <option <?php if($patient_info['bloodgroup'] === 'AB') echo 'selected="selected"';?>value="AB">AB</option>
                  <option <?php if($patient_info['bloodgroup'] === 'O') echo 'selected="selected"';?> value="O">O</option>
                
                </select></td>
		</tr>
		
		<tr>
			<th>
			<select class="form-control" name="birth_year">
			<option value = ""> Birth Year [Now <?php echo $patient_info['birthyear']?>]
		     <?php	
		        for ($birth_year = 1920; $birth_year <= date('Y'); $birth_year++): ?>
                  
                <option value = "<?php echo $birth_year ?>"> <?php echo $birth_year; ?> </option> 
            <?php endfor; ?>    
                </select>
		   </th>
				
							<td><button class = "btn btn-success" type = "submit" name = "update_patient">Update Patient</td>

	<td><input name = "patient_id" style = "display:none;"type = "number" class = "form-control"value = "<?php echo $patient_info['id']; ?>"></td>

		</tr>

			</form>	
		<!--end of main form -->
		
		
	
	</table>
	</form>

	
	




