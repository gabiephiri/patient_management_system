 
<?php include("includes/load.php");
$gottenId = $_GET['id'];
$patient_info = find_by_id ('patients', $gottenId);

$page_title = 'Manage Patients';
$user = current_user();
$docId = $user['id'];

 ?>
  <?php
 if(isset($_POST['submit_sym_test'])){
   $req_field = array('symptoms', 'test_suggestions');
   validate_fields($req_field);
   $symptoms = remove_junk($db->escape($_POST['symptoms']));
   $test_suggestions = remove_junk($db->escape($_POST['test_suggestions']));
   $patient_id = remove_junk($db->escape($_POST['patient_id']));
  
		 
   if(empty($errors)){
      $sql  = "UPDATE medication set status = 'laboratory', symptoms = '{$symptoms}', tests = '{$test_suggestions}', doctor = '{$docId}' WHERE patient_id = {$patient_id}"  ;
      if($db->query($sql)){
		  insert_act('symptoms and test suggestions', 'added', '1');
        $session->msg("s", "Successfully added  symptoms and test suggestions");
        redirect('doc_patients.php',false);
      } else {
		  		  insert_act('symptoms and test suggestions', 'added', '0');

        $session->msg("d", "Sorry failed to add symptoms and test suggestions.");
        redirect('doc_patients.php',false);
      }
   }
   
    else
    {
     $session->msg("d", $errors);
     redirect('doc_patients',false);
   }
  
 }
?>
    <?php
	include('doctor_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Reception</a>
            </li>
            <li class="breadcrumb-item active">Manage Patients</li>
			<li class="breadcrumb-item active">All Patients</li>
          </ol>
		</div>
		
		
        <div class="row">
		<!-- start with table of users -->

		
		
		<!-- end table of  users --->
          <div class="col-md-12 employeeform">
            <p id="message"></p>
            <form method="post" action = "add_sym_rec.php">
             <table class="table table-striped">
		
		<tr>
		<th><strong> Add Symptoms and Lab Test Suggestions for  <span style = 'color:green'><?php echo $patient_info['fname']. ' '.$patient_info['sname']; ?></b></th>
		
		</tr>
		<tr colspan = '2'>
             <th> <textarea type="text"name="symptoms" class="form-control" placeholder="Symptoms" ></textarea></th>

		</tr>
		<tr colspan = '2'>
				<td><textarea type="text"  name="test_suggestions" class="form-control" placeholder= "Test Suggestions " required></textarea></td>

   
		</tr>
		<tr colspan = '2'>
				<td><button type="submit"  name="submit_sym_test" class="btn btn-success">Submit Symptoms &amp; Test Suggestions for</button></td>

   
		</tr>
		<tr>
		  <th><input type="number"name="patient_id" style = "display:none"class="form-control" value = "<?php echo $patient_info['id']; ?>"></th>

		
		</tr>
		
			
	</table>
	
            </form>
       </div>

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">
           function deletePatient(x){
          sweetAlert({   title: "Proceed delete patient?!",
                                text: "patient record will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_patient.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
										  
  }

 </script>
  </body>
  
</html>
