 
<?php include("includes/load.php");
$from_all = find_pharm_patients ();
 ?>
 
 <?php
 
 //finanicial calculations 
 // 1. grand total charges
 $queryTotalDocPrice = "SELECT SUM(doctor_price) as grandTotalDoc FROM medication";
 $executeTotalDoc = $db->query($queryTotalDocPrice);
 $totalDocResultsArray = mysqli_fetch_array($executeTotalDoc);
 $totalDocPrice = $totalDocResultsArray['grandTotalDoc'];
 
 
 $queryTotalTestPrice = "SELECT SUM(test_price) as grandTotalTest FROM medication";
 $executeTotalTest = $db->query($queryTotalTestPrice);
 $totalTestResultsArray = mysqli_fetch_array($executeTotalTest);
 $totalTestPrice = $totalTestResultsArray['grandTotalTest'];
 
 $queryTotalMedPrice = "SELECT SUM(medical_price) as grandTotalMed FROM medication";
 $executeTotalMed = $db->query($queryTotalMedPrice);
 $totalMedResultsArray = mysqli_fetch_array($executeTotalMed);
 $totalMedPrice = $totalMedResultsArray['grandTotalMed'];
 
 
 $grandestTotal = number_format (($totalDocPrice + $totalTestPrice + $totalMedPrice), 2);
 
 //2. doctor charges 
 
 $today = date ('Y-m-d');
 $thisMonth = date('Y-m');
 $thisYear = date ('Y');
 
 $queryTotalDocPriceToday = "SELECT SUM(doctor_price) as grandTotalDocToday FROM medication WHERE DATE_FORMAT(date_updated, '%Y-%m-%d') = '{$today}'";
 $executeTotalDocPriceToday = $db->query($queryTotalDocPriceToday);
 $totalDocResultsTodayArray = mysqli_fetch_array($executeTotalDocPriceToday);
 $totalDocPriceToday = $totalDocResultsTodayArray['grandTotalDocToday'];
 
 $queryTotalDocPriceThisMonth = "SELECT SUM(doctor_price) as grandTotalDocThisMonth FROM medication WHERE DATE_FORMAT(date_updated, '%Y-%m') ='{$thisMonth}' ";
 $executeTotalDocPriceThisMonth = $db->query($queryTotalDocPriceThisMonth);
 $totalDocResultsThisMonthArray = mysqli_fetch_array($executeTotalDocPriceThisMonth);
 $totalDocPriceThisMonth = $totalDocResultsThisMonthArray['grandTotalDocThisMonth'];
 
 $queryTotalDocPriceThisYear = "SELECT SUM(doctor_price) as grandTotalDocThisYear FROM medication WHERE DATE_FORMAT(date_updated, '%Y') ='{$thisYear}' ";
 $executeTotalDocPriceThisYear = $db->query($queryTotalDocPriceThisYear);
 $totalDocResultsThisYearArray = mysqli_fetch_array($executeTotalDocPriceThisYear);
 $totalDocPriceThisYear = $totalDocResultsThisYearArray['grandTotalDocThisYear'];
 
 //3. test results
 
 $queryTotalTestPriceToday = "SELECT SUM(test_price) as grandTotalTestToday FROM medication WHERE DATE_FORMAT(date_updated, '%Y-%m-%d') = '{$today}'";
 $executeTotalTestPriceToday = $db->query($queryTotalTestPriceToday);
 $totalTestResultsTodayArray = mysqli_fetch_array($executeTotalTestPriceToday);
 $totalTestPriceToday = $totalTestResultsTodayArray['grandTotalTestToday'];
 
 $queryTotalTestPriceThisMonth = "SELECT SUM(test_price) as grandTotalTestThisMonth FROM medication WHERE DATE_FORMAT(date_updated, '%Y-%m') ='{$thisMonth}' ";
 $executeTotalTestPriceThisMonth = $db->query($queryTotalTestPriceThisMonth);
 $totalTestResultsThisMonthArray = mysqli_fetch_array($executeTotalTestPriceThisMonth);
 $totalTestPriceThisMonth = $totalTestResultsThisMonthArray['grandTotalTestThisMonth'];
 
 $queryTotalTestPriceThisYear = "SELECT SUM(test_price) as grandTotalTestThisYear FROM medication WHERE DATE_FORMAT(date_updated, '%Y') ='{$thisYear}' ";
 $executeTotalTestPriceThisYear = $db->query($queryTotalTestPriceThisYear);
 $totalTestResultsThisYearArray = mysqli_fetch_array($executeTotalTestPriceThisYear);
 $totalTestPriceThisYear = $totalTestResultsThisYearArray['grandTotalTestThisYear'];
 
 //4. medical tests
 
 $queryTotalMedPriceToday = "SELECT SUM(medical_price) as grandTotalMedToday FROM medication WHERE DATE_FORMAT(date_updated, '%Y-%m-%d') = '{$today}'";
 $executeTotalMedPriceToday = $db->query($queryTotalMedPriceToday);
 $totalMedResultsTodayArray = mysqli_fetch_array($executeTotalMedPriceToday);
 $totalMedPriceToday = $totalMedResultsTodayArray['grandTotalMedToday'];
 
 $queryTotalMedPriceThisMonth = "SELECT SUM(medical_price) as grandTotalMedThisMonth FROM medication WHERE DATE_FORMAT(date_updated, '%Y-%m') ='{$thisMonth}' ";
 $executeTotalMedPriceThisMonth = $db->query($queryTotalMedPriceThisMonth);
 $totalMedResultsThisMonthArray = mysqli_fetch_array($executeTotalMedPriceThisMonth);
 $totalMedPriceThisMonth = $totalMedResultsThisMonthArray['grandTotalMedThisMonth'];
 
 $queryTotalMedPriceThisYear = "SELECT SUM(medical_price) as grandTotalMedThisYear FROM medication WHERE DATE_FORMAT(date_updated, '%Y') ='{$thisYear}' ";
 $executeTotalMedPriceThisYear = $db->query($queryTotalMedPriceThisYear);
 $totalMedResultsThisYearArray = mysqli_fetch_array($executeTotalMedPriceThisYear);
 $totalMedPriceThisYear = $totalMedResultsThisYearArray['grandTotalMedThisYear'];
 ?>

    <?php
	include('bursar_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Bursar</a>
            </li>
            <li class="breadcrumb-item active">Manage Patients &amp; Finances</li>
			<li class="breadcrumb-item active">All Patients' Charges</li>
          </ol>
		</div>
		
		
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-7" id = "printable_part">
		 		 	<h3>Financial Summaries &nbsp; &nbsp; <button class = "btn btn-success fa fa-print pull-right" onclick = "printElem('printable_part');"></button></h3>
					 


		 	<h3>Totals by Patient</h3>
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
              <thead>
              <tr>
                <th>#</th>
                  <th>Name</th>
				   <th>Doctor Price (MK)</th>
				   	 <th>Test Price (MK)</th>
				<th>Medicine  Price (MK)</th>
				<th> Date In </th>
                </tr>
				 
              </thead>
			    <tfoot>
				<tr style = "background-color:silver">
                <th></th>
				<th>Grand Total </th>
                  <th><?php echo number_format($totalDocPrice,2) ?></th>
				   <th><?php echo number_format($totalTestPrice, 2) ?></th>
				   	 <th><?php echo number_format($totalMedPrice, 2) ?></th>
				<th style = "color:green"><?php echo $grandestTotal ?></th>
				<th></th>
				
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($from_all  as $d_patient): 
	  $test_results = $d_patient ['test_results'];
	  $test_price = $d_patient ['test_price'];
	  $doctor_price = $d_patient['doctor_price'];
	  $medical_price = $d_patient['medical_price'];
	  $totalPrice = $test_price + $doctor_price + $medical_price;
	  ?>

		<tr class='prev' id="pre<?php echo $d_patient['id']?>">
      <td><?php echo count_id() ?></td>
       <td><?php echo $d_patient['fname']. ' '. $d_patient['sname'];?> </td>
		<td><?php echo number_format($doctor_price, 2); ?></td>
				<td><?php echo number_format($test_price, 2); ?></td>
						<td><?php echo number_format($medical_price, 2); ?></td>


		
        <td><?php echo read_date($d_patient['dateadded']);?></td>

         </tr>
	<?php endforeach; ?>		
		
			  
			  </tbody>		
         </table>
		

          </div>
		
		
		
		<!-- end table of  users --->
          <div class="col-md-5 employeeform" id = "printable_part2">
		  
		  <h5> &nbsp;</h5>
		
		  <h3> Totals by Time &nbsp; &nbsp; <button class = "btn btn-success fa fa-print pull-right" onclick = "printElem('printable_part2');"></button></h3>

            <p id="message"></p>
            <form method="post" id="insert">
             <table class="table table-striped">
		
		<tr style = "background-color:#FD8705">
		<th colspan = '2'>Today (<?php echo date('j F, Y')?>)</th>
		</tr>
		
		<tr>
		<th >Doctor Price Total</th>
		 <td> <?php echo"MK ". number_format($totalDocPriceToday, 2); ?></td>

		</tr>
		
		<tr >
		<th>Test Price Total</th>
		 <td> <?php echo "MK ".number_format ($totalTestPriceToday, 2); ?></td>

		</tr>
		
		<tr>
		<th>Medical Price Total</th>
		 <td> <?php echo "MK ".number_format($totalMedPriceToday, 2); ?></td>

		</tr>
		<tr style = "background-color:#FD8705">
		<th colspan = '2'>This Month (<?php echo date('F')?>)</th>
		</tr>
		
		<tr>
		<th>Doctor Price Total</th>
		 <td> <?php echo "MK ". number_format($totalDocPriceThisMonth, 2); ?></td>

		</tr>
		
		<tr>
		<th>Test Price Total</th>
		 <td> <?php echo "MK ".number_format($totalTestPriceThisMonth,2); ?></td>

		</tr>
		
		<tr>
		<th>Medical Price Total</th>
		 <td> <?php echo "MK ".number_format($totalMedPriceThisMonth, 2); ?></td>

		</tr>

     <tr style = "background-color:#FD8705">
		<th  colspan = '2'>This Year (<?php echo date ('Y'); ?>) </th>
		</tr>
		
		<tr>
		<th>Doctor Price Total</th>
		 <td> <?php echo "MK ".number_format($totalDocPriceThisYear, 2); ?></td>

		</tr>
		
		<tr>
		<th>Test Price Total</th>
		 <td> <?php echo "MK ".number_format($totalTestPriceThisYear, 2); ?></td>

		</tr>
		
		<tr>
		<th>Medical Price Total</th>
		 <th> <?php echo "MK ". number_format($totalMedPriceThisYear, 2); ?></th>

		</tr>		
	</table>
            </form>
       </div>
          <div class="col-md-5 viewemployee" style="display:none;"></div>

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
     <script> 
      $(document).ready(function(){


        //View Employee
        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "bursar_patient_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
        
		 
		
		

		
	
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
  </body>
  
</html>
