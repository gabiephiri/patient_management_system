 
<?php include("includes/load.php");
$from_all = find_pharm_patients ();
 ?>

    <?php
	include('bursar_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Bursar</a>
            </li>
            <li class="breadcrumb-item active">Manage Patients &amp; Finances</li>
			<li class="breadcrumb-item active">All Patients' Charges</li>
          </ol>
		</div>
		
		
        <div class="row">
		<!-- start with table of users -->
		
		 <div class="col-md-7" id = "printable_part">
		 	<h3>Financial Statements  <button class = "btn btn-success fa fa-print pull-right" onclick = "printElem('printable_part');"></button></h3>

			
            <table class="table table-striped" id = "dataTable" cellspacing = "0">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Total Price</th>
				   	<th>Added</th>
                   <th>Actions</th>
				 
              </thead>
			    <tfoot>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Total Price</th>
				  <th>Added</th>
                  <th> Actions</th> 
                </tr>
              </tfoot>
              <tbody>
			  <?php
	  
	  foreach ($from_all  as $d_patient): 
	  $test_results = $d_patient ['test_results'];
	  $test_price = $d_patient ['test_price'];
	  $doctor_price = $d_patient['doctor_price'];
	  $medical_price = $d_patient['medical_price'];
	  $totalPrice = $test_price + $doctor_price + $medical_price;
	  ?>

		<tr class='prev' id="pre<?php echo $d_patient['id']?>">
      <td><?php echo count_id() ?></td>
       <td><?php echo $d_patient['fname']. ' '. $d_patient['sname'];?> </td>
		<td><?php echo number_format($totalPrice, 2); ?></td>
        <td><?php echo read_date($d_patient['dateadded']);?></td>
        
		<td>
		<div class='btn btn-info btn-xs view-button' did='<?php echo $d_patient['id']?>'><i class = 'fa fa-info' title = "info & create new"data-toggle = "tooltip" data-placement="bottom"></i></div>
		   
                
   
	 </td>
         </tr>
	<?php endforeach; ?>		
		
			  
			  </tbody>		
         </table>
		

          </div>
		
		
		
	
          <div class="col-md-5 viewemployee" id = "printable_part2" style="display:none;"></div>

         
		  </div>
		  
        </div>
      </div>
	  </div>
	  </div>

    </div><!-- /.container -->
 
          

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
     <script> 
      $(document).ready(function(){


        //View Employee
        $(document).on('click', '.view-button', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var eid = $(this).attr("did"); 
          var Data = {'eid':eid};
          $.ajax({
            url: "bursar_patient_info.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		
		
		 
		  //View Employee
        $(document).on('click', '.edit-button-lab', function(){ 
          $('.employeeform').css("display","none");
          $('.viewemployee').css("display","block");
          var jid = $(this).attr("lid"); 
          var Data = {'bid':jid};
          $.ajax({
            url: "add_med_lab.php",
            method: "get",
            data: Data,
            dataType: "html",
            success: function(res){
              $('.viewemployee').html(res);
            }
          })
          $(document).on('click', '.addEmployee', function(){ 
            $('.employeeform').css("display","block");
            $('.viewemployee').css("display","none");
          })
		 
        });
		

		 function deleteUser(x){
           sweetAlert({   title: "Proceed to delete user?!",
                                text: "user account will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_user.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } 
										  
					});
		
		 

		 }
		
		
	
	 $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
	 });


      });
    </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	
	<script type="text/javascript">
           function deletePatient(x){
          sweetAlert({   title: "Proceed delete patient?!",
                                text: "patient record will be removed from database!",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#FF0000",
                                confirmButtonText: "delete",
                                cancelButtonText: "cancel",
                                closeOnConfirm: false,
                                closeOnCancel: false 
                             },
                             function(isConfirm){
                                      if (isConfirm) {
                                           window.location.href="delete_patient.php?id="+x;   } 
                                     else { 
                                          sweetAlert("Cancelled", "", "error");   } });
										  
  }

 </script>
  </body>
  
</html>
