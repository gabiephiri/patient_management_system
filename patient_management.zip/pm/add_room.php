 
<?php
require_once("includes/load.php");
$all_rooms= find_all('rooms');
$count_rooms = count_by_id('rooms');
$total_rooms = $count_rooms['total'];
$page_title = 'Patient Room Assignments';
 ?>
  <?php
 if(isset($_POST['submit_room'])){
   $req_field = array('name', 'capacity');
   validate_fields($req_field);
   $name = remove_junk($db->escape($_POST['name']));
    $capacity= remove_junk($db->escape($_POST['capacity']));
		 
   if(empty($errors)){
      $sql  = "INSERT INTO rooms ( name, capacity)";
      $sql .= " VALUES ('{$name}', '{$capacity}')";
	 
      if($db->query($sql)){
		
		 
		  insert_act('room', 'added', '1');
        $session->msg("s", "Successfully added room");
        redirect('rooms.php',false);
		 
		 
		
      } 
	  else {
		  		  insert_act('room', 'added', '0');

        $session->msg("d", "Sorry failed to create room.");
        redirect('rooms.php',false);
      }
   }
   else {
     $session->msg("d", $errors);
     redirect('rooms.php',false);
   }
 }
?>
 <?php
	include('nurse_header.php');?> 
	<!-- to bring the header with the left menu, change the included header file to 'general_header.php' -->
    <div class="col-md-12"> 
	<!-- also change the class to 'container' -->
  <?php echo display_msg($msg); ?>
      <div class="page-header">
       <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Nurse</a>
            </li>
            <li class="breadcrumb-item active">Rooms</li>
			<li class="breadcrumb-item active">All Rooms</li>
			<li class="breadcrumb-item">
              <a href="add_room.php">Nurse</a>
            </li>

          </ol>
		</div>     


	 <div class="col-md-5 employeeform">
            <form method="post" action = "add_room.php">
             <table class="table table-striped">
		
		
		<tr>
             <th> <input type="text" name="name" class="form-control" placeholder="Name " required></th>
			<td><input type="number" name="capacity" class="form-control" placeholder="" required></td>
						<td><button type="submit" name = "submit_room"class="btn btn-block btn-info">Submit</button></td>

		</tr>
		<tr>
			
		</tr>
			
	</table>
        </form>
       </div>
	   </div>
	   