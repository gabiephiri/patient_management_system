<?php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'patients';

$db = mysqli_connect($host, $username, $password, $database) or die ('No database connection');
?>