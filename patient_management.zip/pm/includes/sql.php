<?php
  require_once('load.php');

/*--------------------------------------------------------------*/
/* Function for find all database table rows by table name
/*--------------------------------------------------------------*/
function find_all($table) {
   global $db;
   if(tableExists($table))
   {
     return find_by_sql("SELECT * FROM ".$db->escape($table). " ORDER BY id DESC");
   }
}

function find_all_limited($table, $limit) {
   global $db;
   if(tableExists($table))
   {
     return find_by_sql("SELECT * FROM ".$db->escape($table)."ORDER BY dateAdded DESC LIMIT ". $limit);
   }
}
/*--------------------------------------------------------------*/
/* Function for Perform queries
/*--------------------------------------------------------------*/
function find_by_sql($sql)
{
  global $db;
  $result = $db->query($sql);
  $result_set = $db->while_loop($result);
 return $result_set;
}
/*--------------------------------------------------------------*/
/*  Function for Find data from table by id
/*--------------------------------------------------------------*/
function find_by_id($table,$id)
{
  global $db;
  $id = (int)$id;
    if(tableExists($table)){
          $sql = $db->query("SELECT * FROM {$db->escape($table)} WHERE id='{$db->escape($id)}' LIMIT 1");
          if($result = $db->fetch_assoc($sql))
            return $result;
          else
            return null;
     }
}


function find_by_doc_id($id)
{
  global $db;
  $id = (int)$id;
  
          $sql = $db->query("SELECT * FROM doctors WHERE userId='{$db->escape($id)}' LIMIT 1");
          if($result = $db->fetch_assoc($sql))
            return $result;
          else
            return null;
     
}

/** -------------------------------------------------------------------------*/
/* function to get the space for the next record using some numerical column
/*------------------------------------------------------------------------------*/

function find_last()
{
  global $db;
  
  
          $sql = $db->query("SELECT MAX(group_level) as last_one FROM user_groups");
          if($result = $db->fetch_assoc($sql))
            return $result;
		  
          else
            return null;
     
}
/*--------------------------------------------------------------*/
/* Function for Delete data from table by id
/*--------------------------------------------------------------*/
 function delete_by_id($table,$id)
{
  global $db;
  if(tableExists($table))
   {
    $sql = "DELETE FROM ".$db->escape($table);
    $sql .= " WHERE id=". $db->escape($id);
    $sql .= " LIMIT 1";
    $db->query($sql);
    return ($db->affected_rows() === 1) ? true : false;
   }
}



/*--------------------------------------------------------------*/
/* Function for Count id  By table name
/*--------------------------------------------------------------*/

function count_by_id($table){
  global $db;
  if(tableExists($table))
  {
    $sql    = "SELECT COUNT(id) AS total FROM ".$db->escape($table);
    $result = $db->query($sql);
     return($db->fetch_assoc($result));
  }
}
/*--------------------------------------------------------------*/
/* Determine if database table exists
/*--------------------------------------------------------------*/
function tableExists($table){
  global $db;
  $table_exit = $db->query('SHOW TABLES FROM '.DB_NAME.' LIKE "'.$db->escape($table).'"');
      if($table_exit) {
        if($db->num_rows($table_exit) > 0)
              return true;
         else
              return false;
      }
  }
 /*--------------------------------------------------------------*/
 /* Login with the data provided in $_POST,
 /* coming from the login form.
/*--------------------------------------------------------------*/
  function authenticate($username='', $password='') {
    global $db;
    $username = $db->escape($username);
    $password = $db->escape($password);
    $sql  = sprintf("SELECT id,username,password,user_level FROM users WHERE username ='%s' LIMIT 1", $username);
    $result = $db->query($sql);
    if($db->num_rows($result)){
      $user = $db->fetch_assoc($result);
      $password_request = sha1($password);
      if($password_request === $user['password'] ){
        return $user['id'];
      }
    }
   return false;
  }
  

  /*--------------------------------------------------------------*/
  /* Login with the data provided in $_POST,
  /* coming from the login_v2.php form.
  /* If you used this method then remove authenticate function.
 /*--------------------------------------------------------------*/
   function authenticate_v2($username='', $password='') {
     global $db;
     $username = $db->escape($username);
     $password = $db->escape($password);
     $sql  = sprintf("SELECT id,username,password,user_level FROM users WHERE username ='%s' LIMIT 1", $username);
     $result = $db->query($sql);
     if($db->num_rows($result)){
       $user = $db->fetch_assoc($result);
       $password_request = sha1($password);
       if($password_request === $user['password'] ){
         return $user;
       }
     }
    return false;
   }


  /*--------------------------------------------------------------*/
  /* Find current log in user by session id
  /*--------------------------------------------------------------*/
  function current_user(){
      static $current_user;
      global $db;
      if(!$current_user){
         if(isset($_SESSION['user_id'])):
             $user_id = intval($_SESSION['user_id']);
             $current_user = find_by_id('users',$user_id);
        endif;
      }
    return $current_user;
  }
  
  /*---------------------------------------------------------------*/
  /* find current logged in candidate
  /*----------------------------------------------------------------*/
  
   function current_candidate(){
      static $current_candidate;
      global $db;
      if(!$current_candidate){
         if(isset($_SESSION['candidate_id'])):
             $candidate_id = intval($_SESSION['candidate_id']);
             $current_candidate = find_by_id('candidates',$candidate_id);
        endif;
      }
    return $current_candidate;
  }
  /*--------------------------------------------------------------*/
  /* Find all user by
  /* Joining users table and user gropus table
  /*--------------------------------------------------------------*/
  function find_all_user(){
      global $db;
      $results = array();
      $sql = "SELECT u.id,u.first_name,u.last_name, u.email_address, u.username,u.user_level,u.status,u.last_login,";
      $sql .="g.group_name ";
      $sql .= " FROM users u, user_groups g ";
	  $sql .= " WHERE g.group_level = u.user_level";
	  $sql .= " ORDER by u.first_name ASC ";
      $result = find_by_sql($sql);
      return $result;
  }
  
  
  
  /*--------------------------------------------------------------*/
  /* Function to update the last log in of a user
  /*--------------------------------------------------------------*/

 function updateLastLogIn($user_id)
	{
		global $db;
    $date = make_date();
    $sql = "UPDATE users SET last_login='{$date}' WHERE id ='{$user_id}' LIMIT 1";
    $result = $db->query($sql);
    return ($result && $db->affected_rows() === 1 ? true : false);
	}
	
	
	function updateCLastLogIn($candidate_id)
	{
		global $db;
    $date = make_date();
    $sql = "UPDATE candidates SET last_login='{$date}' WHERE id ='{$candidate_id}' LIMIT 1";
    $result = $db->query($sql);
    return ($result && $db->affected_rows() === 1 ? true : false);
	}

  /*--------------------------------------------------------------*/
  /* Find all Group name
  /*--------------------------------------------------------------*/
  function find_by_groupName($val)
  {
    global $db;
    $sql = "SELECT group_name FROM user_groups WHERE group_name = '{$db->escape($val)}' LIMIT 1 ";
    $result = $db->query($sql);
    return($db->num_rows($result) === 0 ? true : false);
  }
  
  
  function users_in_group($groupName)
  {
    global $db;
    $sql = "SELECT u.id, u.first_name, u.last_name, ug.group_name FROM users u, user_groups ug WHERE u.user_level = ug.group_level AND ug.group_name LIKE '%{$db->escape($groupName)}%'";
      $result = find_by_sql($sql);
     return $result;
  }
  
 
  function find_patients_by_status($statusName)
  {
	  global $db;
	 $sql = " SELECT p.dateadded, p.id, p.fname,p.sname, p.sex FROM patients p, medication m WHERE p.id = m.patient_id AND m.status like '%{$db->escape($statusName)}%' ORDER by p.dateadded DESC";
	 $result = find_by_sql($sql);
	 return $result;
  }
  
   function count_by_patient_status ($statusName)
  {
	  global $db;
	  $sql  = "SELECT COUNT(id) as total FROM medication WHERE status LIKE '%{$db->escape($statusName)}%'";
	  $result = $db->query($sql);
     return($db->fetch_assoc($result));
  }
  
   function find_pharm_patients()
  {
	  global $db;
	 $sql = " SELECT p.dateadded, p.id, p.fname,p.sname, p.sex, m.medical, m.test_results,m.test_price, m.doctor_price, m.tests, m.medical_price FROM patients p, medication m WHERE p.id = m.patient_id AND (m.status like '%laboratory%' OR m.status like '%pharm%' or m.status like '%finish%')ORDER by p.dateadded DESC";
	 $result = find_by_sql($sql);
	 return $result;
  }
  
 
  /*
  --------------------------------------------------------------*/
  /* Find group level
  /*--------------------------------------------------------------*/
  function find_by_groupLevel($level)
  {
    global $db;
    $sql = "SELECT group_level FROM user_groups WHERE group_level = '{$db->escape($level)}' LIMIT 1 ";
    $result = $db->query($sql);
    return($db->num_rows($result) === 0 ? true : false);
  }
  /*--------------------------------------------------------------*/
  /* Function for cheaking which user level has access to page
  /*--------------------------------------------------------------*/
   function page_require_level($require_level){
     global $session;
     $current_user = current_user();
     $login_level = find_by_groupLevel($current_user['user_level']);
     //if user not login
     if (!$session->isUserLoggedIn(true)):
            $session->msg('d','Please login...');
            redirect('index.php', false);
      //if Group status Deactive
     elseif($login_level['group_status'] === '0'):
           $session->msg('d','This level user has been band!');
           redirect('home.php',false);
      //cheackin log in User level and Require level is Less than or equal to
     elseif($current_user['user_level'] <= (int)$require_level):
              return true;
      else:
            $session->msg("d", "Sorry! you dont have permission to view the page.");
            redirect('home.php', false);
        endif;

     }


  function dateDiff($date1, $date2)
{
	return round((strtotime($date1)- strtotime($date2))/86400);
}
function insert_act($object, $act, $status)
{
	$user = current_user();
	$userId = $user['id'];
  global $db;
    $sql = "INSERT INTO acts_log";
    $sql .= " (object, action, status, actor)";
	$sql .=" VALUES ('{$object}','{$act}', '{$status}','{$userId}')";
    $db->query($sql);
	
   
}
 function is_patient_roomless($patientId)
{
  global $db;
      $med_info = find_med_by_patient_id($patientId);
	  $patient_type = $med_info['type'];
	  $patient_room = $med_info['room_number'];
	   return (($patient_type === '2' AND is_null($patient_room)) ? TRUE : FALSE);   
}

function is_outpatient($patientId)
{
  global $db;
      $med_info = find_med_by_patient_id($patientId);
	  $patient_type = $med_info['type'];
	   return (($patient_type === '2') ? TRUE: FALSE);   
}



 function find_med_by_patient_id($id)
{
  global $db;
          $sql = $db->query("SELECT * FROM medication  WHERE patient_id='{$id}'");
          if($result = $db->fetch_assoc($sql))
            return $result;
          else
            return null;    
}
function find_doc($id)
{
  global $db;
          $sql = $db->query("SELECT * FROM doctors  WHERE userId='{$id}'");
          if($result = $db->fetch_assoc($sql))
            return $result;
          else
            return null;    
}

function update_medicine_quantity ($medId, $takenOut)
{

   global $db;
   
   $medicine_info = find_by_id ('medicine', $medId);
   $oldQuantity = $medicine_info['amount'];
   $newQuantity = $oldQuantity - $takenOut;
   
   $insertQuery = "UPDATE medicine SET amount = '{$newQuantity}' WHERE id = '{$medId}'";
   $insertResult = $db->query($insertQuery);
   return($insertQuery AND $db->affected_rows() === 1 ? true : false); 
}

function update_room_remaining ($roomId)
{

   global $db; 
   $one = 1;
   $sub_one = (int)$one;
   $updateRoomRemaining = "UPDATE rooms SET room_remaining=room_remaining-'{$sub_one}' WHERE id = '{$roomId}'";
   $insertResult = $db->query($updateRoomRemaining);
   return($updateRoomRemaining AND $db->affected_rows() === 1 ? true : false); 
}

function release_a_room ($roomId)
{

   global $db; 
   $one = 1;
   $plus_one = (int)$one;
   $updateRoomRemaining = "UPDATE rooms SET room_remaining=room_remaining+'{$plus_one}' WHERE id = '{$roomId}'";
   $insertResult = $db->query($updateRoomRemaining);
   return($updateRoomRemaining AND $db->affected_rows() === 1 ? true : false); 
}


function is_drug_fresh ($drug_id)
  {
	  $this_drug = find_by_id('medicine', $drug_id);
	  $formatted_medicine_exp_date = substr($this_drug['expiry_date'], 0, 10);
	  return (datediff($formatted_medicine_exp_date, date('y-m-d'))) > 10 ? TRUE :  FALSE;
  }
  
  function count_days_to_expiry($drug_id)
  {
	  $todayDate = date ('Y-m-d');
	  $this_drug = find_by_id('medicine', $drug_id);
	  $formatted_job_exp_date = substr($this_drug['expiry_date'], 0, 10);
	  return (int)dateDiff($formatted_job_exp_date, $todayDate) + 1;
  }
  
  function count_fresh_medicine(){
      global $db;
	  $todayDate = date ('Y-m-d');
      $all_medicine = find_all('medicine');
	  $counter = 0;
	  foreach ($all_medicine as $a_drug){
		  $expDate = substr($a_drug['expiry_date'], 0 , 10);
		  $dateDiff = dateDiff($expDate, $todayDate);
		  if ($dateDiff > 10)
		  {
			  $counter++;
		  }
	  }
   
      return $counter;
  }
  /*--------------------------------------------------------------*/
  /* Function to update the last log in of a user
  /*--------------------------------------------------------------*/
  
  function is_drug_enough($medId)
  {
  
     $drug_info = find_by_id ('medicine', $medId);
	 $amount = $drug_info ['amount'];
	 $least_amount = $drug_info['least_amount'];
	 
	 return ($amount > $least_amount ? TRUE: FALSE);
    
  }
  
  function is_room_free($roomId)
  {
  
     $room_info = find_by_id ('rooms', $roomId);
	 $room_remaining = $room_info['room_remaining'];	 
	 return ($room_remaining > 0 ? TRUE: FALSE);
    
  }
  
 
  function count_low_sup_med ()
  {
      $all_medicine = find_all ('medicine');
	     $low_sup_count = 0;

	  foreach ($all_medicine as $a_drug)
	  {
	     $is_enough = is_drug_enough($a_drug['id']);
		 if (!$is_enough)
		 {
		   $low_sup_count++;
		 }
	  }
	  return $low_sup_count;
 }

  

?>
