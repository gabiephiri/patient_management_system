-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 27, 2018 at 12:57 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `patients`
--

-- --------------------------------------------------------

--
-- Table structure for table `acts_log`
--

DROP TABLE IF EXISTS `acts_log`;
CREATE TABLE IF NOT EXISTS `acts_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `actor` int(11) NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_actor_id` (`actor`)
) ENGINE=MyISAM AUTO_INCREMENT=166 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acts_log`
--

INSERT INTO `acts_log` (`id`, `object`, `action`, `status`, `actor`, `dateAdded`) VALUES
(1, 'job', 'added', '0', 1, '2018-10-30 13:23:27'),
(2, 'account', 'updated', '1', 1, '2018-11-06 01:16:34'),
(3, 'account', 'updated', '1', 1, '2018-11-06 01:16:45'),
(4, 'user', 'added', '1', 1, '2018-11-06 01:33:56'),
(5, 'user account', 'updated', '1', 1, '2018-11-06 01:34:30'),
(6, 'account', 'updated', '1', 1, '2018-11-08 09:32:30'),
(7, 'account', 'updated', '1', 1, '2018-11-08 10:46:46'),
(8, 'user', 'added', '1', 1, '2018-11-09 05:33:53'),
(9, 'account', 'updated', '1', 1, '2018-11-10 00:53:10'),
(10, 'user', 'added', '1', 1, '2018-11-10 00:55:16'),
(11, 'patient', 'added', '1', 1, '2018-11-10 04:07:15'),
(12, 'patient', 'updated', '0', 1, '2018-11-10 04:40:36'),
(13, 'patient', 'updated', '1', 1, '2018-11-10 04:43:48'),
(14, 'patient doc', 'updated', '0', 1, '2018-11-10 07:01:51'),
(15, 'patient doc', 'updated', '0', 1, '2018-11-10 07:06:51'),
(16, 'patient', 'updated', '1', 1, '2018-11-10 07:24:23'),
(17, 'patient', 'updated', '0', 1, '2018-11-10 07:39:05'),
(18, 'patient', 'updated', '0', 1, '2018-11-10 07:40:30'),
(19, 'patient', 'updated', '0', 1, '2018-11-10 07:41:08'),
(20, 'patient', 'updated', '1', 1, '2018-11-10 07:44:03'),
(21, 'patient', 'updated', '1', 1, '2018-11-10 08:33:03'),
(22, 'patient', 'updated', '1', 1, '2018-11-10 08:40:29'),
(23, 'patient account', 'updated', '1', 1, '2018-11-10 08:45:19'),
(24, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 19:36:25'),
(25, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 19:43:40'),
(26, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 19:43:58'),
(27, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 19:51:36'),
(28, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 19:54:47'),
(29, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 20:00:42'),
(30, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 20:00:54'),
(31, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 20:01:45'),
(32, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 20:02:45'),
(33, 'symptoms and test suggestions', 'added', '1', 1, '2018-11-10 20:51:18'),
(34, 'symptoms and test suggestions', 'added', '1', 1, '2018-11-10 20:53:35'),
(35, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 21:39:39'),
(36, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 21:41:39'),
(37, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 21:42:32'),
(38, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 21:58:58'),
(39, 'symptoms and test suggestions', 'updated', '1', 1, '2018-11-10 22:08:11'),
(40, 'medicine cost', 'charged', '1', 1, '2018-11-10 22:55:57'),
(41, 'medicine', 'added', '1', 1, '2018-11-10 23:46:50'),
(42, 'medicine', 'updated', '1', 1, '2018-11-11 00:03:29'),
(43, 'user account', 'updated', '1', 1, '2018-11-11 00:06:02'),
(44, 'medical drug', 'deleted', '1', 4, '2018-11-11 00:15:19'),
(45, 'test cost', 'charged', '1', 4, '2018-11-11 00:51:47'),
(46, 'password', 'changed', '1', 4, '2018-11-10 12:31:45'),
(47, 'password', 'changed', '1', 4, '2018-11-10 12:34:29'),
(48, 'password', 'changed', '1', 4, '2018-11-10 12:37:31'),
(49, 'password', 'changed', '1', 4, '2018-11-10 12:39:31'),
(50, 'account', 'updated', '1', 4, '2018-11-10 12:46:38'),
(51, 'user', 'added', '1', 4, '2018-11-10 13:08:06'),
(52, 'account', 'updated', '1', 4, '2018-11-10 13:35:07'),
(53, 'account', 'updated', '0', 4, '2018-11-10 13:35:26'),
(54, 'account', 'updated', '0', 4, '2018-11-10 13:35:40'),
(55, 'account', 'updated', '1', 4, '2018-11-10 13:37:28'),
(56, 'user', 'added', '1', 4, '2018-11-10 13:40:25'),
(57, 'user account', 'updated', '1', 4, '2018-11-10 17:02:36'),
(58, 'user', 'added', '1', 4, '2018-11-10 17:05:32'),
(59, 'user', 'added', '1', 4, '2018-11-10 17:23:28'),
(60, 'password', 'changed', '1', 4, '2018-11-10 17:25:40'),
(61, 'user account', 'updated', '1', 4, '2018-11-10 17:26:02'),
(62, 'user', 'added', '1', 4, '2018-11-10 17:27:17'),
(63, 'password', 'changed', '1', 9, '2018-11-10 17:36:25'),
(64, 'user', 'added', '1', 4, '2018-11-10 17:40:53'),
(65, 'password', 'changed', '1', 10, '2018-11-10 17:44:29'),
(66, 'password', 'changed', '1', 6, '2018-11-10 17:51:27'),
(67, 'account', 'updated', '1', 5, '2018-11-10 18:01:51'),
(68, 'password', 'changed', '1', 5, '2018-11-10 18:02:15'),
(69, 'user account', 'updated', '1', 4, '2018-11-10 18:16:36'),
(70, 'user', 'added', '1', 4, '2018-11-10 18:19:28'),
(71, 'password', 'changed', '1', 11, '2018-11-10 18:21:33'),
(72, 'doctor', 'updated', '1', 4, '2018-11-30 07:09:01'),
(73, 'doctor', 'updated', '1', 4, '2018-11-30 07:09:10'),
(74, 'doctor type price', 'updated', '0', 9, '2018-11-30 08:22:45'),
(75, 'doctor type price', 'updated', '0', 9, '2018-11-30 08:25:42'),
(76, 'doctor type price', 'updated', '0', 9, '2018-11-30 08:30:12'),
(77, 'doctor type price', 'updated', '0', 9, '2018-11-30 08:30:26'),
(78, 'doctor type price', 'updated', '0', 9, '2018-11-30 08:30:38'),
(79, 'doctor type price', 'updated', '1', 9, '2018-11-30 08:31:35'),
(80, 'doctor type price', 'updated', '0', 9, '2018-11-30 08:33:17'),
(81, 'doctor type price', 'updated', '0', 9, '2018-11-30 08:33:56'),
(82, 'doctor type price', 'updated', '0', 9, '2018-11-30 08:35:50'),
(83, 'doctor type price', 'updated', '0', 9, '2018-11-30 08:36:35'),
(84, 'doctor type price', 'updated', '1', 9, '2018-11-30 08:39:43'),
(85, 'doctor type price', 'updated', '1', 9, '2018-11-30 08:53:36'),
(86, 'doctor type price', 'updated', '1', 9, '2018-11-30 09:00:31'),
(87, 'doctor type price', 'updated', '1', 9, '2018-11-30 09:00:49'),
(88, 'doctor type price', 'updated', '1', 9, '2018-11-30 09:04:04'),
(89, 'doctor type price', 'updated', '1', 9, '2018-11-30 09:04:48'),
(90, 'doctor type price', 'updated', '1', 9, '2018-11-30 09:05:00'),
(91, 'doctor type price', 'updated', '1', 9, '2018-11-30 09:05:10'),
(92, 'doctor type price', 'updated', '1', 9, '2018-11-30 09:05:19'),
(93, 'doctor group', ' price changed', '1', 9, '2018-11-30 09:49:05'),
(94, 'doctor group', ' price changed', '1', 9, '2018-11-30 09:49:36'),
(95, 'doctor group', ' price changed', '1', 9, '2018-11-30 09:49:50'),
(96, 'doctor group', ' price changed', '1', 9, '2018-11-30 09:51:02'),
(97, 'user', 'added', '1', 4, '2018-11-30 10:15:01'),
(98, 'Doctor type', 'updated', '0', 4, '2018-11-30 10:15:21'),
(99, 'Doctor type', 'updated', '0', 4, '2018-11-30 10:15:39'),
(100, 'doctor', 'updated', '1', 4, '2018-11-30 10:18:56'),
(101, 'Doctor type', 'updated', '0', 4, '2018-11-30 10:19:07'),
(102, 'doctor', ' assigned type', '1', 4, '2018-11-30 10:20:38'),
(103, 'patient', 'added', '1', 9, '2018-11-30 10:47:13'),
(104, 'patient', 'added', '1', 9, '2018-11-30 10:49:51'),
(105, 'patient account', 'updated', '1', 9, '2018-11-30 10:53:55'),
(106, 'medicine', 'updated', '1', 5, '2018-11-30 11:57:00'),
(107, 'medicine', 'updated', '1', 5, '2018-11-30 11:58:42'),
(108, 'medicine', 'updated', '1', 5, '2018-11-30 12:02:52'),
(109, 'medicine', 'updated', '1', 5, '2018-11-30 12:04:10'),
(110, 'medicine', 'added', '1', 5, '2018-11-30 12:18:46'),
(111, 'symptoms and test suggestions', 'updated', '1', 11, '2018-11-30 21:05:07'),
(112, 'symptoms and test suggestions', 'updated', '1', 11, '2018-11-30 21:08:26'),
(113, 'symptoms and test suggestions', 'updated', '1', 11, '2018-11-30 21:10:43'),
(114, 'symptoms and test suggestions', 'updated', '1', 11, '2018-11-30 21:15:34'),
(115, 'symptoms and test suggestions', 'updated', '1', 11, '2018-11-30 21:17:38'),
(116, 'symptoms and test suggestions', 'updated', '1', 11, '2018-11-30 22:05:30'),
(117, 'symptoms and test suggestions', 'updated', '1', 11, '2018-11-30 22:06:21'),
(118, 'user', 'added', '1', 4, '2018-11-30 22:16:30'),
(119, 'room', 'added', '1', 13, '2018-12-01 03:17:25'),
(120, 'room', 'added', '1', 13, '2018-12-01 03:20:21'),
(121, 'room', 'deleted', '1', 13, '2018-12-01 03:25:33'),
(122, 'room', 'added', '1', 13, '2018-12-01 04:55:39'),
(123, 'room', 'added', '1', 13, '2018-12-01 04:56:44'),
(124, 'room', 'added', '1', 13, '2018-12-01 04:59:27'),
(125, 'room', 'deleted', '1', 13, '2018-12-01 04:59:33'),
(126, 'room', 'deleted', '1', 13, '2018-12-01 04:59:47'),
(127, 'room', 'deleted', '1', 13, '2018-12-01 04:59:50'),
(128, 'room', 'deleted', '1', 13, '2018-12-01 04:59:53'),
(129, 'patient', ' assigned room', '1', 13, '2018-12-01 05:55:01'),
(130, 'patient', ' assigned room', '1', 13, '2018-12-01 06:19:26'),
(131, 'test cost', 'charged', '1', 7, '2018-12-01 06:42:42'),
(132, 'test cost', 'charged', '1', 7, '2018-12-01 06:43:12'),
(133, 'test cost', 'charged', '1', 7, '2018-12-01 06:43:35'),
(134, 'test cost', 'charged', '1', 7, '2018-12-01 06:44:54'),
(135, 'medicine cost', 'charged', '1', 5, '2018-12-01 06:54:12'),
(136, 'medicine cost', 'charged', '1', 5, '2018-12-01 06:54:32'),
(137, 'medicine cost', 'charged', '0', 5, '2018-12-01 06:57:22'),
(138, 'medicine cost', 'charged', '0', 5, '2018-12-01 06:57:54'),
(139, 'medicine cost', 'charged', '1', 5, '2018-12-01 06:59:19'),
(140, 'patient', 'updated', '1', 9, '2018-12-01 23:52:28'),
(141, 'patient', 'added', '1', 11, '2018-12-02 11:10:31'),
(142, 'patient', 'added', '1', 11, '2018-12-02 11:20:43'),
(143, 'patient account', 'updated', '1', 11, '2018-12-02 11:31:01'),
(144, 'patient account', 'updated', '1', 11, '2018-12-02 11:31:05'),
(145, 'patient account', 'updated', '1', 11, '2018-12-02 11:31:08'),
(146, 'patient account', 'updated', '1', 11, '2018-12-02 11:31:12'),
(147, 'patient', 'added', '1', 9, '2018-12-02 11:32:37'),
(148, 'patient account', 'updated', '1', 9, '2018-12-02 11:36:09'),
(149, 'patient', 'added', '1', 9, '2018-12-02 11:39:00'),
(150, 'patient', 'added', '1', 9, '2018-12-02 11:42:40'),
(151, 'patient', 'added', '1', 9, '2018-12-02 11:45:43'),
(152, 'patient', 'added', '1', 9, '2018-12-02 11:49:49'),
(153, 'patient', 'added', '1', 9, '2018-12-02 11:50:59'),
(154, 'symptoms and test suggestions', 'added', '1', 11, '2018-12-17 20:37:18'),
(155, 'symptoms and test suggestions', 'added', '1', 11, '2018-12-17 20:50:07'),
(156, 'symptoms and test suggestions', 'updated', '1', 11, '2018-12-18 15:10:02'),
(157, 'symptoms and test suggestions', 'added', '1', 11, '2018-12-18 15:58:02'),
(158, 'symptoms and test suggestions', 'added', '1', 11, '2018-12-18 16:03:13'),
(159, 'test cost', 'charged', '1', 7, '2018-12-18 16:04:41'),
(160, 'patient', 'updated', '1', 9, '2018-12-20 01:29:53'),
(161, 'patient', 'updated', '1', 9, '2018-12-20 01:30:08'),
(162, 'patient', 'updated', '1', 9, '2018-12-20 01:30:51'),
(163, 'patient', 'updated', '1', 9, '2018-12-20 01:31:21'),
(164, 'patient', 'updated', '1', 9, '2018-12-20 01:31:50'),
(165, 'patient', 'updated', '1', 9, '2018-12-20 01:53:00');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
CREATE TABLE IF NOT EXISTS `doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_userId` (`userId`),
  KEY `fk_type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `userId`, `type`) VALUES
(1, 11, 1),
(2, 12, 3);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_types`
--

DROP TABLE IF EXISTS `doctor_types`;
CREATE TABLE IF NOT EXISTS `doctor_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `price` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_types`
--

INSERT INTO `doctor_types` (`id`, `name`, `price`) VALUES
(1, 'Surgeon', 10000),
(2, 'Psychiatrist', NULL),
(3, 'Pediatrician', 1500),
(4, 'Physician', NULL),
(5, 'Gynecologist/Obsterician', NULL),
(6, 'Cardiologist', NULL),
(7, 'Dermatologist', NULL),
(8, 'Endocrinologist', NULL),
(9, 'Gastroenterologist', NULL),
(10, 'Nephrologist', NULL),
(11, 'Opthalmologist', NULL),
(12, 'Otolaryngologist', NULL),
(13, 'Pulmonologist', NULL),
(14, 'Neurologist', NULL),
(15, 'Radiologist', NULL),
(16, 'Anesthesiollogist', NULL),
(17, 'Oncologist', 12200);

-- --------------------------------------------------------

--
-- Table structure for table `medication`
--

DROP TABLE IF EXISTS `medication`;
CREATE TABLE IF NOT EXISTS `medication` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'patient welcomed by reception',
  `symptoms` longtext,
  `tests` longtext,
  `test_results` longtext,
  `medical` longtext,
  `med_comment` varchar(255) NOT NULL DEFAULT 'all medicine given',
  `doctor` int(11) DEFAULT NULL,
  `doctor_price` int(11) DEFAULT NULL,
  `intake_instructions` varchar(255) DEFAULT NULL,
  `test_price` int(11) DEFAULT NULL,
  `medical_price` int(11) DEFAULT NULL,
  `room_number` int(11) DEFAULT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_doctor` (`doctor`),
  KEY `fk_patient` (`patient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medication`
--

INSERT INTO `medication` (`id`, `patient_id`, `status`, `symptoms`, `tests`, `test_results`, `medical`, `med_comment`, `doctor`, `doctor_price`, `intake_instructions`, `test_price`, `medical_price`, `room_number`, `date_updated`, `type`) VALUES
(3, 1, 'finish', NULL, NULL, NULL, NULL, 'all medicine given', 5, 30000, '', NULL, 1230, NULL, '2018-11-10 08:20:28', '1'),
(5, 3, 'finish', 'g', 'de', 'Food deposits between teeth', 'Garani M12X1', 'all medicine given', 5, 30000, '', 3000, 1230, NULL, '2018-11-10 08:20:28', '1'),
(7, 4, 'finish', 'Fatigue\r\nListlessness', 'Blood Pressure Test', 'Confirmed BP', 'Vitamin B12', 'all medicine given', 5, 30000, '', 6000, 1230, NULL, '2018-11-10 08:20:28', '1'),
(8, 5, 'laboratory', 'Kutopa ndi chimfine', 'Kamfuno test', 'fever confirmed', 'Chingombe', 'all medicine given', 11, 30000, '', 4500, 1230, NULL, '2018-11-10 08:20:28', '1'),
(11, 6, 'finish', 'gfhjg', 'ertyuefds', 'Hahaha doc you were lying', 'Quinine LXV: 500Quinine LXV: 1209Fansida: 1000', 'all medicine given', 5, 345600, '', 10000, 1209, 1, '2018-11-10 08:40:29', '2'),
(14, 5, 'laboratory', 'Kutopa ndi chimfine', 'Kamfuno test', NULL, NULL, 'all medicine given', 11, 12345, NULL, NULL, NULL, NULL, '2018-12-01 23:52:28', '1'),
(20, 10, 'patient welcomed by reception', NULL, NULL, NULL, NULL, 'all medicine given', 2, 1500, NULL, NULL, NULL, NULL, '2018-12-02 11:32:37', '1'),
(21, 8, 'laboratory', 'Zingwangwa', 'Fits test', NULL, NULL, 'all medicine given', 11, 1500, NULL, NULL, NULL, NULL, '2018-12-02 11:39:00', '1'),
(22, 8, 'laboratory', 'Zingwangwa', 'Fits test', NULL, NULL, 'all medicine given', 11, 1500, NULL, NULL, NULL, NULL, '2018-12-02 11:42:40', '1'),
(23, 9, 'labdoctor', 'Convulsions', 'Kupenga test', 'Truly chimfine', 'Fansida: 10 ,', 'all medicine given', 7, 1500, NULL, 1000, NULL, NULL, '2018-12-02 11:50:59', '1'),
(24, 9, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 10000, NULL, NULL, NULL, NULL, '2018-12-20 01:29:53', '1'),
(25, 9, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 10000, NULL, NULL, NULL, NULL, '2018-12-20 01:29:53', '1'),
(26, 8, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 1200, NULL, NULL, NULL, NULL, '2018-12-20 01:30:08', '1'),
(27, 8, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 1200, NULL, NULL, NULL, NULL, '2018-12-20 01:30:08', '1'),
(28, 7, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 12300, NULL, NULL, NULL, NULL, '2018-12-20 01:30:51', '1'),
(29, 7, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 12300, NULL, NULL, NULL, NULL, '2018-12-20 01:30:51', '1'),
(30, 9, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 11, 23000, NULL, NULL, NULL, NULL, '2018-12-20 01:31:21', '1'),
(31, 9, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 11, 23000, NULL, NULL, NULL, NULL, '2018-12-20 01:31:21', '1'),
(32, 9, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 54640, NULL, NULL, NULL, NULL, '2018-12-20 01:31:50', '1'),
(33, 9, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 54640, NULL, NULL, NULL, NULL, '2018-12-20 01:31:50', '1'),
(34, 9, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 123498, NULL, NULL, NULL, NULL, '2018-12-20 01:53:00', '1'),
(35, 9, 'recdoctor', NULL, NULL, NULL, NULL, 'all medicine given', 12, 123498, NULL, NULL, NULL, NULL, '2018-12-20 01:53:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

DROP TABLE IF EXISTS `medicine`;
CREATE TABLE IF NOT EXISTS `medicine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `amount` decimal(25,2) NOT NULL,
  `least_amount` int(11) NOT NULL,
  `expiry_date` timestamp NULL DEFAULT NULL,
  `last_touched` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`id`, `name`, `price`, `amount`, `least_amount`, `expiry_date`, `last_touched`) VALUES
(2, 'Quinine LXV', 520, '-2119.00', 40, '2018-12-29 08:00:00', '2018-11-30 20:04:10'),
(3, 'Fansida', 1200, '120.00', 100, '2019-04-18 07:00:00', '2018-11-30 20:18:46');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(30) NOT NULL,
  `receivers` text NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender`, `receivers`, `subject`, `message`, `dateAdded`) VALUES
(1, 'hr@nbm.co.mw', 'chamvekaagent@gmail,com, 0993025347, lunzuwholesalers@yahoo.com', 'Congrats and interview schedule', 'You impressed NBM and have a great chance of becoming our agent. Come for a short interview with original business documents on 28 October from 08:30 AM', '2018-10-05 05:23:26');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
CREATE TABLE IF NOT EXISTS `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `sex` varchar(10) NOT NULL,
  `bloodgroup` varchar(5) NOT NULL,
  `birthyear` int(4) NOT NULL,
  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `fname`, `sname`, `email`, `address`, `phone`, `sex`, `bloodgroup`, `birthyear`, `dateadded`) VALUES
(1, 'Marita', 'Chikondamoyo', 'maritachikondamoyo@gmail.com', 'Chirimba Blantyre', '099234567', 'Female', 'o', 1998, '2018-11-10 02:29:12'),
(3, 'John', 'Chimbalu', 'johnchimbalu@gmail.com', 'Chimbalu Residence', '09967543', 'Male', 'o', 1980, '2018-11-10 02:29:12'),
(5, 'Felix', 'Chinere', 'felichinere@yahoo.com', 'Sigma MW, Chichiri', '09978474638', 'Male', 'A', 1999, '2018-11-10 02:29:12'),
(6, 'Jenniffers', 'Chikanza', 'jchikanza@yahoo.com', NULL, '099383744339', 'Female', 'B', 1936, '2018-11-10 04:07:15'),
(7, 'Mfana', 'Wochepa', 'mfanawochepa@gmail.com', NULL, '747483847', 'Female', 'B', 2016, '2018-11-30 10:47:13'),
(8, 'Old', 'patient', 'oldpatient@gmail.com', NULL, '87383782738', 'Female', 'AB', 1936, '2018-12-02 11:49:49'),
(9, 'Young', 'Patients', 'youngpatient@gmail.com', NULL, '7367363871', 'Female', 'B', 2016, '2018-12-02 11:50:59');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
CREATE TABLE IF NOT EXISTS `rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `capacity` int(11) NOT NULL,
  `room_remaining` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `name`, `capacity`, `room_remaining`) VALUES
(1, 'PAED-1', 120, 12);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(10) NOT NULL,
  `first_name` varchar(60) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `other_names` varchar(45) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email_address` varchar(45) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `status` int(1) NOT NULL DEFAULT '1',
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_user_level` (`user_level`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `title`, `first_name`, `last_name`, `other_names`, `username`, `email_address`, `phone_number`, `password`, `user_level`, `image`, `status`, `last_login`) VALUES
(5, 'Mr', 'Trial', 'Pharmacist', 'I', 'trialpharmacist', 'trialpharmacist@pm.com', '039938349', '95e3be6d87c74ea4487f72e551dcb22fe59fc14a', 4, 'no_image.jpg', 1, '2018-12-20 01:45:37'),
(7, 'Mrs', 'Trial', 'Laboratorist', 'TLAB', 'triallaboratorist', 'triallab@pms.com', '023343564', '09e7ccdc42723210904b1d1d1834ada570ab859f', 5, 'no_image.jpg', 1, '2018-12-18 19:06:59'),
(4, 'Dr', 'Trial', 'Admin', 'TADMIN', 'trialadmin', 'trialadmin@pms.com', '099774374637', 'd945929386963ce74a987a2d2ba43797a276777a', 1, 'no_image.jpg', 1, '2018-12-01 07:44:00'),
(11, 'Prof', 'Trial', 'Doctor', 'TDOC', 'trialdoctor', 'trialdoctor@pms.com', '0998765432', '16a2d0b804ad12bdec8e1c133aa35db6fbede0c7', 2, 'no_image.jpg', 1, '2018-12-18 16:05:01'),
(9, 'Mr', 'Trial ', 'Receptionist', 'TREC', 'trialreceptionist', 'trialreceptionist@pms.com', '78433948394', '2e5fa37de1db0c4501af7ae1fd5bd0718e776286', 6, 'no_image.jpg', 1, '2018-12-20 01:48:55'),
(10, 'Mrs', 'Trial', 'Bursar', 'TBURSAR', 'trialbursar', 'trialbursar', '088657432', 'e2f0ba79839e8e322ba2f7e9be5b461fd5bcd798', 3, 'no_image.jpg', 1, '2018-11-10 17:42:20'),
(12, 'Dr', 'Trial', 'trialpediatrician', 'Ped', 'trialpediatrician', 'trialpediatrician@pm.com', '783798273', '2ff597ffe85bb6d2c67b59bf767e0617f9e195fd', 2, 'no_image.jpg', 1, NULL),
(13, 'Mrs', 'Trial', 'trialnurse', 'Nurse', 'trialnurse', 'trialnurse@gmail.com', '7483749', '70006829fdcc4f2dc898002b9da06bbf572c5f18', 7, 'no_image.jpg', 1, '2018-12-18 15:48:39');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
CREATE TABLE IF NOT EXISTS `user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(150) NOT NULL,
  `group_level` int(11) NOT NULL,
  `group_status` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_level` (`group_level`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `group_name`, `group_level`, `group_status`) VALUES
(1, 'Admin', 1, 1),
(2, 'Doctor', 2, 1),
(3, 'Bursar', 3, 1),
(4, 'Pharmacist', 4, 1),
(5, 'Lab Technician', 5, 1),
(6, 'Receptionist', 6, 1),
(7, 'Nurse', 7, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
